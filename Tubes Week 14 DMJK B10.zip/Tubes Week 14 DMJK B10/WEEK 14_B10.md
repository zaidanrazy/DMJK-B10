
# [Proyek Perancangan & Implementasi Jaringan Enterprise PT. Nusantara Network] - [Pekan 14:    Implementasi Keamanan & Pengujian ] 
## Anggota Kelompok dan Peran 
- **Muhammad Irgie Yanuar (10221022)** - Network Architect  
- **Noviansyah(10231072)** - Network Engineer  
- **Desnita Dwi Putri (10231030)** - Network Services Specialist  
- **Zaidan Ramadhan Arrazy (10221028)** - Security & Documentation Specialist   
## Daftar Isi 
1. [Pendahuluan](#pendahuluan)  
2. [Isi Laporan](#isi-laporan)    
1. [Kendala dan Solusi](#kendala-dan-solusi)  
2. [Kesimpulan](#kesimpulan)  
## **Pendahuluan**  

### **Latar Belakang**  
PT. Nusantara Network merupakan perusahaan di bidang teknologi informasi yang memiliki dua lokasi kantor (pusat dan cabang) dengan total 6 departemen dan server farm. Perusahaan membutuhkan infrastruktur jaringan yang aman, terkelola dengan baik, dan mampu mendukung pertumbuhan bisnis di masa depan. Proyek ini bertujuan untuk merancang solusi jaringan enterprise yang mengintegrasikan seluruh konsep jaringan komputer yang telah dipelajari.

### **Tujuan**  
1. Merancang topologi jaringan yang memenuhi kebutuhan bisnis PT. Nusantara Network  
2. Mengimplementasikan segmentasi jaringan menggunakan VLAN  
3. Menyediakan konektivitas antar-gedung melalui WAN dengan routing dinamis (OSPF)  
4. Menerapkan layanan jaringan (DHCP, DNS, NAT) dan keamanan (ACL)  
5. Membangun dokumentasi teknis yang komprehensif  

### **Ruang Lingkup**  
Proyek mencakup:  
- Perancangan topologi fisik dan logis  
- Pembagian subnet dan pengalamatan IP  
- Konfigurasi VLAN, trunking, dan routing antar-VLAN  
- Implementasi OSPF untuk koneksi WAN antar-gedung  
- Penyediaan layanan DHCP, DNS, dan NAT  
- Penerapan Access Control List (ACL)  
- Pengujian end-to-end dan troubleshooting  
 
## Isi Laporan

### Implementasi Access Control List (ACL) Sesuai Kebijakan Keamanan. 

![Konfigurasi ACL](konfACL.jpg)

Konfigurasi Access Control List (ACL) pada gambar berfungsi untuk mengatur akses jaringan berdasarkan VLAN dan alamat IP, sehingga setiap departemen atau bagian dalam jaringan memiliki batasan akses sesuai dengan kebutuhannya. ACL ini membantu mengamankan jaringan dengan memastikan bahwa hanya perangkat atau pengguna yang berwenang dapat mengakses sumber daya tertentu.

Misalnya, VLAN 10 yang digunakan oleh departemen IT diizinkan untuk mengakses semua tujuan tanpa batasan. Hal ini dilakukan dengan menambahkan aturan yang mengizinkan semua lalu lintas dari jaringan 192.168.10.0/24 ke berbagai tujuan. Di sisi lain, VLAN 20 yang digunakan oleh departemen Finance hanya boleh mengakses server di ruang server dengan aturan yang secara spesifik mengizinkan akses ke jaringan 192.168.100.0/24, sementara lalu lintas lainnya ditolak. Hal yang sama berlaku untuk VLAN 30 yang digunakan oleh bagian SOM, di mana aksesnya dibatasi agar hanya bisa mengakses internet, dengan aturan yang mencegah koneksi ke jaringan internal tetapi tetap mengizinkan komunikasi dengan jaringan eksternal. Untuk VLAN 40 yang digunakan oleh Marketing, konfigurasi ACL membatasi aksesnya hanya ke departemen Finance, memastikan bahwa informasi penting hanya dapat diakses oleh mereka yang berkepentingan. Sedangkan VLAN 50 yang digunakan oleh bagian Operational memiliki aturan yang lebih ketat, hanya mengizinkan akses ke layanan tertentu seperti DNS (port UDP 53) dan HTTP (port TCP 80) ke server yang ditentukan, sementara semua jenis koneksi lainnya diblokir. Dengan cara ini, konfigurasi ACL membantu membangun jaringan yang lebih aman dan terstruktur, memastikan bahwa setiap departemen atau pengguna hanya memiliki akses yang diperlukan untuk menjalankan tugasnya, serta mencegah akses yang tidak diinginkan ke sumber daya jaringan lainnya.

![Pemasangan ACL](pemasanganACL.jpg)

Pemasangan Access Control List (ACL) 100 ke semua interface bertujuan untuk mengontrol lalu lintas jaringan secara keseluruhan. Dengan menerapkan ACL ini, setiap VLAN atau bagian dalam jaringan akan memiliki aturan akses yang sesuai dengan kebutuhannya, sehingga keamanan dan efisiensi dalam penggunaan jaringan dapat terjamin.

Proses konfigurasi dimulai dengan menentukan aturan dalam ACL 100, seperti mengizinkan atau menolak akses berdasarkan alamat IP dan port tertentu. Setelah aturan ini dibuat, langkah berikutnya adalah menerapkannya ke semua interface yang ada di router. Pada perangkat jaringan Cisco, ACL dapat diterapkan pada interface dengan perintah seperti ip access-group 100 in atau ip access-group 100 out, yang berarti bahwa aturan ACL akan digunakan untuk lalu lintas yang masuk ke atau keluar dari interface tersebut. Misalnya, jika ada interface yang terhubung ke VLAN 10 untuk departemen IT, kita akan menerapkan ACL agar mereka dapat mengakses semua sumber daya jaringan tanpa pembatasan. Sementara itu, untuk VLAN 20 yang digunakan oleh departemen Finance, ACL diterapkan untuk memastikan mereka hanya dapat mengakses server di ruang server, tetapi tidak ke bagian lain dalam jaringan. Aturan serupa dibuat untuk VLAN lainnya, seperti VLAN 30 untuk bagian SOM yang hanya boleh mengakses internet, VLAN 40 untuk Marketing yang hanya boleh berkomunikasi dengan Finance, dan VLAN 50 untuk Operational yang hanya diperbolehkan menggunakan layanan DNS dan HTTP.

Dengan menerapkan ACL ini ke semua interface, setiap bagian dalam jaringan memiliki batasan akses yang jelas, sehingga data lebih terlindungi dari akses yang tidak diinginkan. Hal ini juga membantu dalam pengelolaan bandwidth dan memastikan bahwa setiap perangkat hanya berkomunikasi dengan tujuan yang diperbolehkan.

### Pengujian Menyeluruh Semua Fitur Jaringan. 
![Uji Akses Server](ujiakses-server.jpg)

Pengujian akses server dilakukan untuk memastikan bahwa aturan yang telah dikonfigurasi dalam Access Control List (ACL) berjalan sesuai dengan yang diharapkan. Dalam konteks jaringan ini, setiap VLAN memiliki batasan akses tertentu, sehingga penting untuk melakukan pengujian guna memastikan perangkat-perangkat dalam VLAN hanya dapat berkomunikasi dengan tujuan yang telah ditentukan.

Langkah pertama dalam pengujian akses server adalah melakukan koneksi dari setiap VLAN ke server yang seharusnya bisa diakses. Misalnya, dari VLAN Finance kita mencoba melakukan ping atau mengakses layanan dari Server Room. Jika koneksi berhasil, maka aturan ACL telah berjalan dengan baik. Namun, jika tidak bisa terhubung, kita perlu memeriksa aturan ACL untuk memastikan bahwa alamat IP yang digunakan sesuai dengan konfigurasi yang telah ditetapkan. Selanjutnya, kita juga menguji apakah VLAN yang memiliki batasan akses benar-benar terblokir dari sumber yang tidak diizinkan. Sebagai contoh, VLAN Marketing hanya boleh mengakses Finance, maka kita bisa mencoba melakukan koneksi dari Marketing ke jaringan lain yang seharusnya tidak bisa diakses, seperti ke VLAN SOM atau Operational. Jika koneksi gagal, itu berarti aturan ACL bekerja sebagaimana mestinya dalam membatasi akses.

Selain itu, pengujian akses dilakukan dengan melihat apakah protokol tertentu seperti HTTP dan DNS telah diterapkan dengan benar untuk VLAN Operational. Jika VLAN ini hanya diizinkan mengakses layanan DNS dan HTTP ke server tertentu, kita bisa mencoba mengakses situs web atau melakukan pencarian DNS dari dalam VLAN ini. Jika akses berjalan lancar sesuai aturan, maka konfigurasi ACL telah diterapkan dengan benar. Terakhir, setelah seluruh pengujian dilakukan, kita bisa memeriksa log dan statistik router untuk memastikan bahwa aturan ACL tidak menyebabkan gangguan yang tidak diinginkan terhadap lalu lintas jaringan. Jika ditemukan anomali seperti akses yang seharusnya diblokir tetapi berhasil dilakukan, maka konfigurasi perlu ditinjau ulang dan diperbaiki.

![Blok IP](blok-ip.jpg)

Untuk memblokir komunikasi antara VLAN 30 dan VLAN 20, kita menggunakan Access Control List (ACL) yang memastikan bahwa perangkat dalam VLAN 30 tidak dapat mengakses perangkat di VLAN 20. Hal ini penting untuk menjaga isolasi jaringan dan memastikan bahwa hanya lalu lintas yang diizinkan yang dapat melewati aturan ACL. Setelah aturan deny ini diterapkan, kita juga perlu memastikan bahwa ada aturan yang tetap mengizinkan lalu lintas lain yang diperlukan untuk operasional jaringan. Oleh karena itu, setelah menambahkan aturan pemblokiran, kita dapat menambahkan aturan untuk mengizinkan lalu lintas yang sesuai, misalnya membolehkan VLAN 30 mengakses internet atau tujuan lain yang dibutuhkan. Terakhir, pengujian perlu dilakukan untuk memastikan bahwa konfigurasi ACL berjalan dengan benar. Pengujian ini bisa dilakukan dengan mencoba melakukan koneksi dari perangkat VLAN 30 ke VLAN 20 dan memeriksa apakah koneksi tersebut benar-benar terblokir. Jika berhasil diblokir, maka konfigurasi ACL telah diterapkan dengan baik dan jaringan lebih terstruktur serta aman sesuai dengan kebutuhannya.

![Cek ACL](cek-acl.jpg)

Pada ping pertama, terlihat bahwa aturan ACL telah diterapkan, yang menyebabkan blokir akses dari VLAN tertentu ke VLAN lainnya sesuai konfigurasi yang telah dibuat. Misalnya, jika ada aturan yang secara spesifik menolak komunikasi dari VLAN 30 ke VLAN 20, maka semua paket data yang berasal dari VLAN 30 dan ditujukan ke VLAN 20 akan diblokir oleh router. Artinya, perangkat di VLAN 30 tidak bisa mengakses perangkat di VLAN 20 melalui ping, file sharing, atau protokol lainnya.

Di bagian tengah gambar, terlihat bahwa dilakukan pengecekan alamat IP dari perangkat lain untuk memastikan apakah akses benar-benar terblokir. Biasanya, pengecekan ini dilakukan dengan perintah seperti ping atau traceroute untuk melihat apakah perangkat dapat mencapai tujuan yang seharusnya terblokir oleh ACL. Jika hasil pengecekan menunjukkan bahwa perangkat dari VLAN 30 tidak bisa berkomunikasi dengan VLAN 20, maka aturan ACL bekerja dengan baik. Sebaliknya, jika koneksi masih memungkinkan, maka ada kemungkinan kesalahan dalam konfigurasi ACL yang perlu diperbaiki.

Pada bagian bawah gambar, ACL telah dimatikan atau dihapus. Setelah ACL dinonaktifkan, lalu lintas antara VLAN yang sebelumnya diblokir kini bisa berjalan normal. Perangkat dari VLAN 30 yang sebelumnya tidak bisa mengakses VLAN 20 kini dapat melakukan komunikasi tanpa hambatan. Penghapusan ACL dilakukan dengan perintah seperti no access-list 100 atau dengan menghapus aturan spesifik yang menyebabkan pemblokiran. Setelah ACL dihapus, pengujian dilakukan kembali untuk memastikan bahwa perangkat kini dapat berkomunikasi dengan bebas tanpa batasan.

Proses ini menunjukkan bagaimana ACL mempengaruhi akses dalam jaringan, baik saat aturan diterapkan maupun saat dihapus. Dengan ACL, administrator dapat mengontrol komunikasi antar-VLAN untuk meningkatkan keamanan dan memastikan bahwa hanya lalu lintas yang diperbolehkan yang dapat terjadi. Sementara itu, saat ACL dinonaktifkan, jaringan kembali ke kondisi terbuka tanpa batasan akses. Pengaturan ini sangat penting dalam mengelola keamanan dan efisiensi lalu lintas data dalam sebuah sistem jaringan.

###  Troubleshooting dan Perbaikan Masalah. 
![Troubleshooting](cek-troubleshooting.jpg)

Troubleshooting dilakukan untuk menemukan dan memperbaiki masalah dalam konfigurasi jaringan, khususnya yang berkaitan dengan Access Control List (ACL). Ketika aturan ACL diterapkan, ada kemungkinan bahwa perangkat tertentu tidak dapat berkomunikasi sesuai yang diharapkan, sehingga perlu dilakukan pengecekan dan pemecahan masalah agar jaringan kembali berjalan normal.

Langkah pertama dalam troubleshooting adalah mengidentifikasi perangkat atau VLAN yang mengalami kendala. Misalnya, jika VLAN 30 tidak dapat mengakses internet seperti yang seharusnya, maka kita perlu memastikan bahwa aturan ACL yang mengizinkan akses ke jaringan eksternal sudah benar. Pengecekan awal bisa dilakukan dengan menggunakan perintah ping ke alamat IP tujuan, baik di dalam maupun di luar jaringan. Jika ping gagal, maka ada kemungkinan aturan ACL telah memblokir akses yang tidak seharusnya. Langkah berikutnya adalah mengecek konfigurasi ACL dengan melihat daftar aturan yang diterapkan pada router atau switch. Perintah seperti show access-lists digunakan untuk menampilkan aturan yang sedang berlaku, sehingga kita dapat melihat apakah ada kesalahan dalam penulisan aturan. Jika ditemukan aturan yang tidak sesuai, misalnya ada aturan deny yang seharusnya permit, maka konfigurasi ACL perlu diperbaiki.

Selain itu, kita juga bisa melakukan pengecekan pada interface yang menerapkan ACL. Perintah seperti show ip interface digunakan untuk melihat apakah ACL sudah diterapkan ke interface yang benar. Jika ACL diterapkan pada interface yang salah atau arah lalu lintasnya tidak sesuai, maka perangkat tidak akan bisa berkomunikasi sebagaimana mestinya. Dalam hal ini, aturan ACL perlu direvisi dan diterapkan ulang dengan perintah yang tepat. Setelah dilakukan perubahan atau perbaikan, langkah terakhir adalah menguji kembali akses jaringan dengan mencoba melakukan koneksi dari VLAN yang bermasalah. Jika perangkat kini bisa berkomunikasi seperti yang diharapkan, maka troubleshooting berhasil dilakukan. 


## **Kendala dan Solusi**  

## **Kesimpulan**  
Pada pekan ini, fokus utama adalah pada implementasi keamanan jaringan menggunakan Access Control List (ACL) dan pengujian terhadap efektivitasnya. ACL berhasil diterapkan pada semua interface router untuk mengatur hak akses antar-VLAN sesuai kebijakan yang ditentukan masing-masing departemen.
