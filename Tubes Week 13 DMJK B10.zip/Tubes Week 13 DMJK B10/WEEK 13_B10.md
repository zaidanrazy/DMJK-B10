
# [Proyek Perancangan & Implementasi Jaringan Enterprise PT. Nusantara Network] - [Pekan 13:    Implementasi Layanan Jaringan] 
## Anggota Kelompok dan Peran 
- **Muhammad Irgie Yanuar (10221022)** - Network Architect  
- **Noviansyah(10231072)** - Network Engineer  
- **Desnita Dwi Putri (10231030)** - Network Services Specialist  
- **Zaidan Ramadhan Arrazy (10221028)** - Security & Documentation Specialist   
## Daftar Isi 
1. [Pendahuluan](#pendahuluan)  
2. [Isi Laporan](#isi-laporan)    
1. [Kendala dan Solusi](#kendala-dan-solusi)  
2. [Kesimpulan](#kesimpulan)  
## **Pendahuluan**  

### **Latar Belakang**  
PT. Nusantara Network merupakan perusahaan di bidang teknologi informasi yang memiliki dua lokasi kantor (pusat dan cabang) dengan total 6 departemen dan server farm. Perusahaan membutuhkan infrastruktur jaringan yang aman, terkelola dengan baik, dan mampu mendukung pertumbuhan bisnis di masa depan. Proyek ini bertujuan untuk merancang solusi jaringan enterprise yang mengintegrasikan seluruh konsep jaringan komputer yang telah dipelajari.

### **Tujuan**  
1. Merancang topologi jaringan yang memenuhi kebutuhan bisnis PT. Nusantara Network  
2. Mengimplementasikan segmentasi jaringan menggunakan VLAN  
3. Menyediakan konektivitas antar-gedung melalui WAN dengan routing dinamis (OSPF)  
4. Menerapkan layanan jaringan (DHCP, DNS, NAT) dan keamanan (ACL)  
5. Membangun dokumentasi teknis yang komprehensif  

### **Ruang Lingkup**  
Proyek mencakup:  
- Perancangan topologi fisik dan logis  
- Pembagian subnet dan pengalamatan IP  
- Konfigurasi VLAN, trunking, dan routing antar-VLAN  
- Implementasi OSPF untuk koneksi WAN antar-gedung  
- Penyediaan layanan DHCP, DNS, dan NAT  
- Penerapan Access Control List (ACL)  
- Pengujian end-to-end dan troubleshooting  
 
## Isi Laporan

### Konfigurasi DHCP Server untuk Setiap Departemen.

1. Departemen IT
![Konfigurasi DHCP](dhcp-vlan10.jpg)
Pertama, perintah Router>en digunakan untuk masuk ke mode enable pada router. Setelah itu, perintah Router#conf t digunakan untuk masuk ke mode konfigurasi terminal, di mana pengguna dapat melakukan perubahan pada pengaturan router. Selanjutnya, perintah Router(config)#ip dhcp pool IT_POOL dibuat untuk menciptakan sebuah pool DHCP bernama "IT_POOL", yang akan digunakan untuk memberikan alamat IP secara otomatis kepada perangkat yang terhubung.

Dalam konfigurasi DHCP, pengguna menentukan jaringan yang digunakan dengan perintah Router(dhcp-config)#network 192.168.10.0 255.255.255.0, yang menetapkan jaringan 192.168.10.0 dengan subnet mask 255.255.255.0. Untuk memastikan perangkat yang terhubung mendapatkan alamat gateway yang benar, digunakan Router(dhcp-config)#default-router 192.168.10.1, yang menetapkan 192.168.10.1 sebagai default router. Kemudian, alamat server DNS juga diberikan dengan perintah Router(dhcp-config)#dns-server 192.168.100.1, sehingga perangkat dapat melakukan pencarian nama domain. Setelah selesai mengatur DHCP, pengguna keluar dari mode konfigurasi dengan perintah Router(dhcp-config)#exit.

Pada tahap berikutnya, pengguna mengkonfigurasi VLAN dengan perintah Router(config)#interface vlan 10, yang berarti mereka sedang mengatur interface VLAN 10. Alamat IP diberikan dengan Router(config-if)#ip address 192.168.10.1 255.255.255.0, menetapkan IP 192.168.10.1 dengan subnet mask 255.255.255.0. Namun, muncul pesan kesalahan % 192.168.10.0 overlaps with GigabitEthernet0/0.10, yang mengindikasikan bahwa jaringan 192.168.10.0 bertabrakan dengan jaringan yang telah dikonfigurasi pada interface lain. Untuk mengaktifkan interface VLAN 10, digunakan perintah Router(config-if)#no shutdown, lalu pengguna keluar dari konfigurasi interface dengan Router(config-if)#exit.Secara keseluruhan, konfigurasi ini bertujuan untuk menyediakan layanan DHCP serta mengelola jaringan VLAN pada router. Berikut adalah hasilnya.

![Berhasil](berhasil-vlan10.jpg)

2. Departemen Keuangan
![Konfigurasi DHCP](dhcp-vlan20.jpg)
Pertama-tama masuk ke mode konfigurasi dengan perintah en dan conf t, yang memungkinkan mereka mengubah pengaturan router. Kemudian, mereka membuat pool DHCP bernama "KEUANGAN_POOL" untuk memberikan alamat IP secara otomatis kepada perangkat dalam jaringan. Dalam konfigurasi ini, jaringan yang digunakan adalah 192.168.20.0 dengan subnet mask 255.255.255.0, sehingga semua perangkat yang terhubung akan mendapatkan alamat dalam rentang tersebut. Untuk memastikan komunikasi yang lancar, router juga diatur sebagai gateway dengan IP 192.168.20.1. Selain itu, server DNS yang digunakan adalah 192.168.100.10, yang membantu perangkat dalam pencarian nama domain. Nama domain jaringan ditetapkan sebagai "nusantara.local" agar lebih mudah dikenali oleh perangkat yang ada di dalam jaringan.

Setelah selesai mengatur DHCP, pengguna mengonfigurasi VLAN dengan memilih interface VLAN 20. VLAN ini diberi alamat IP 192.168.20.1, yang sesuai dengan konfigurasi sebelumnya. Untuk memastikan VLAN berfungsi dengan baik, pengguna menjalankan perintah no shutdown, yang mengaktifkan interface tersebut. Setelah selesai, mereka keluar dari mode konfigurasi dan kembali ke tampilan utama router. Secara keseluruhan, konfigurasi ini bertujuan untuk memastikan jaringan berfungsi dengan baik dan perangkat dapat terhubung dengan mudah menggunakan alamat IP yang diberikan secara otomatis oleh DHCP, serta memiliki manajemen jaringan yang lebih terstruktur melalui VLAN.


1. Departemen SDM
![Konfigurasi DHCP](dhcp-vlan30.jpg)
Pertama-tama masuk ke mode konfigurasi dengan perintah en dan conf t, yang memungkinkan mereka mengubah pengaturan router. Setelah itu, mereka membuat pool DHCP bernama "SDM_POOL" untuk memberikan alamat IP secara otomatis kepada perangkat yang terhubung dalam jaringan. Jaringan yang digunakan adalah 192.168.30.0 dengan subnet mask 255.255.255.0, sehingga semua perangkat mendapatkan alamat dalam rentang tersebut. Agar komunikasi berjalan lancar, gateway default ditetapkan sebagai 192.168.30.1. Selain itu, server DNS yang digunakan adalah 192.168.100.10, yang akan membantu perangkat dalam pencarian nama domain. Nama domain jaringan diatur sebagai "nusantara.local" untuk memberi identitas yang jelas pada jaringan ini.

Setelah selesai mengatur DHCP, pengguna mengonfigurasi VLAN dengan memilih interface VLAN 30. Interface ini diberikan alamat IP 192.168.30.1, yang sesuai dengan pengaturan gateway pada DHCP. Agar VLAN dapat berfungsi, perintah no shutdown digunakan untuk mengaktifkan interface tersebut. Setelah konfigurasi selesai, pengguna keluar dari mode konfigurasi dan kembali ke tampilan utama router. Secara keseluruhan, konfigurasi ini bertujuan untuk memastikan perangkat dapat terhubung dengan mudah menggunakan alamat IP yang diberikan otomatis oleh DHCP serta memiliki manajemen jaringan yang lebih terstruktur melalui VLAN.


1. Departemen Marketing
![Konfigurasi DHCP](dhcp-vlan40.jpg)
Pertama-tama masuk ke mode konfigurasi dengan perintah en dan conf t, sehingga mereka dapat melakukan pengaturan pada router. Kemudian, mereka membuat pool DHCP bernama "SDM_POOL" untuk membagikan alamat IP secara otomatis kepada perangkat yang terhubung dalam jaringan. Jaringan yang digunakan adalah 192.168.30.0 dengan subnet mask 255.255.255.0, sehingga semua perangkat mendapatkan alamat dalam rentang tersebut. Agar komunikasi berjalan lancar, gateway default ditetapkan sebagai 192.168.30.1. Selain itu, server DNS yang digunakan adalah 192.168.100.10, yang membantu perangkat dalam pencarian nama domain. Nama domain jaringan diatur sebagai "nusantara.local" untuk memberikan identitas yang jelas pada jaringan ini.

Setelah selesai mengatur DHCP, pengguna mengonfigurasi VLAN dengan memilih interface VLAN 30. Interface ini diberikan alamat IP 192.168.30.1, yang sesuai dengan pengaturan gateway dalam DHCP. Agar VLAN dapat berfungsi, perintah no shutdown digunakan untuk mengaktifkan interface tersebut. Setelah konfigurasi selesai, pengguna keluar dari mode konfigurasi dan kembali ke tampilan utama router. Secara keseluruhan, konfigurasi ini bertujuan untuk memastikan perangkat dapat terhubung dengan mudah menggunakan alamat IP yang diberikan otomatis oleh DHCP serta memiliki manajemen jaringan yang lebih terstruktur melalui VLAN.

![Berhasil](berhasil-vlan40.jpg)

5. Departemen Operasional
![Konfigurasi DHCP](dhcp-vlan50.jpg)
Pertama-tama masuk ke mode konfigurasi dengan perintah en dan conf t, yang memungkinkan untuk melakukan perubahan pada pengaturan router. Kemudian, membuat pool DHCP bernama "SDM_POOL" yang akan digunakan untuk memberikan alamat IP secara otomatis kepada perangkat dalam jaringan. Jaringan yang digunakan adalah 192.168.30.0 dengan subnet mask 255.255.255.0, sehingga semua perangkat yang terhubung akan mendapatkan alamat IP dari rentang ini. Agar komunikasi berjalan lancar, gateway default ditetapkan sebagai 192.168.30.1, yang akan berfungsi sebagai pintu akses utama menuju jaringan lain. Selain itu, server DNS yang digunakan adalah 192.168.100.10, yang membantu perangkat dalam pencarian nama domain. Nama domain jaringan diatur sebagai "nusantara.local" untuk memberikan identitas yang jelas bagi jaringan ini.

Setelah selesai mengatur DHCP, pengguna mengonfigurasi VLAN dengan memilih interface VLAN 30. Interface ini diberikan alamat IP 192.168.30.1, yang sesuai dengan pengaturan gateway dalam DHCP sebelumnya. Agar VLAN dapat berfungsi dengan baik, perintah no shutdown digunakan untuk mengaktifkan interface tersebut. Setelah konfigurasi selesai, pengguna keluar dari mode konfigurasi dan kembali ke tampilan utama router. Secara keseluruhan, konfigurasi ini bertujuan untuk memastikan perangkat dalam jaringan dapat terhubung dengan mudah menggunakan alamat IP yang diberikan secara otomatis oleh DHCP serta memiliki manajemen jaringan yang lebih terstruktur melalui VLAN.


### Implementasi DNS Server untuk Resolusi Nama Internal.
![Konfigurasi DNS](konfDNS.jpg)

Perintah ping 192.168.100.2 digunakan untuk menguji koneksi ke alamat IP tersebut dan berhasil mendapatkan balasan dengan waktu respons yang sangat cepat. Tidak ada paket yang hilang dalam proses ini, menunjukkan bahwa komunikasi antara perangkat berjalan lancar tanpa gangguan jaringan. Selanjutnya, perintah nslookup server.ptnusantara.local digunakan untuk mencari alamat IP yang terkait dengan nama domain server.ptnusantara.local melalui layanan DNS. Hasil yang diperoleh menunjukkan bahwa server DNS yang digunakan terdeteksi sebagai 255.255.255.255, yang mungkin mengindikasikan bahwa sistem menggunakan konfigurasi default atau belum sepenuhnya dikonfigurasi. Namun, perintah ini berhasil menemukan bahwa server.ptnusantara.local memiliki alamat IP 192.168.100.2, yang berarti pencarian nama domain berfungsi dengan baik. Secara keseluruhan, hasil ini menunjukkan bahwa koneksi ke server dapat dilakukan dengan baik, tetapi pengaturan DNS mungkin perlu diperiksa lebih lanjut untuk memastikan konfigurasi jaringan berjalan optimal.

### Konfigurasi NAT untuk Akses Internet.
![Konfigurasi NAT](konfNAT.jpg)
Pada konfigurasi dimulai dengan masuk ke mode konfigurasi menggunakan perintah en dan conf t. Selanjutnya, pengguna membuat Access Control List (ACL) nomor 1, yang mengizinkan jaringan 192.168.0.0/16 untuk menggunakan NAT. Interface GigabitEthernet 0/2 ditetapkan sebagai outside dengan perintah ip nat outside, yang berarti interface ini akan berfungsi sebagai jalur keluar ke internet atau jaringan eksternal. Kemudian, interface GigabitEthernet 0/0 dikonfigurasi sebagai inside menggunakan ip nat inside, sehingga interface ini berfungsi sebagai jalur masuk dari jaringan lokal. Setelah itu, NAT dinamis dikonfigurasi dengan NAT Overload (PAT - Port Address Translation) menggunakan perintah ip nat inside source list 1 interface gigabitEthernet 0/2 overload, yang memungkinkan banyak perangkat dalam jaringan lokal berbagi satu alamat IP publik saat mengakses internet. Setelah konfigurasi selesai, pengguna keluar dari mode konfigurasi dengan perintah exit. Dengan pengaturan ini, router dapat menerjemahkan alamat IP lokal ke alamat IP publik, memungkinkan perangkat dalam jaringan untuk terhubung ke internet dengan cara yang lebih efisien dan terstruktur.

![Konfigurasi NAT](ping-nat.jpg)
Dari perintah ping yang digunakan untuk menguji koneksi ke alamat IP 8.8.8.8, yang merupakan server DNS publik milik Google. Hasilnya menunjukkan bahwa semua paket yang dikirim berhasil diterima kembali tanpa ada yang hilang (0% packet loss), yang berarti koneksi berjalan dengan baik. Dengan hasil ini, dapat dipastikan bahwa koneksi internet bekerja dengan normal tanpa gangguan, sehingga perangkat dapat berkomunikasi dengan server DNS dengan lancar.

## **Kendala dan Solusi**  
Pada week 13 ini terdapat kendala yaitu terdapat kesalahan pada topologi tepatnya pada jumlah PC yang ada di departemen. Jadi, solusinya kami melengkapi topologi sebelum melanjutkan ke bagian konfigurasi pada pekan ini.
Juga terdapat kesulitan pada bagian konfigurasi DHCP, DNS, dan NAT yang membuat kami membutuhkan waktu lebih lama untuk menyelesaikannya.
## **Kesimpulan**  
Pada pekan ini, menjelaskan bagaimana jaringan diatur agar setiap departemen di kantor bisa terhubung dengan internet dan saling berkomunikasi dengan baik. Masing-masing departemen (seperti IT, Keuangan, dan lainnya) diberikan pengaturan IP otomatis lewat DHCP, sehingga perangkat seperti komputer bisa langsung mendapat alamat IP tanpa perlu diatur manual. Setiap departemen juga dipisahkan lewat VLAN agar jaringan lebih rapi dan aman.

Selain itu, DNS Server digunakan agar perangkat bisa mengenali nama-nama domain dalam jaringan internal, seperti server.ptnusantara.local. Lalu, NAT diatur agar semua perangkat bisa mengakses internet dengan membagikan satu alamat IP publik. Setelah diuji, semua pengaturan ini berhasil berjalan dengan baik dan perangkat bisa terhubung ke jaringan dan internet tanpa masalah.
