
# [Proyek Perancangan & Implementasi Jaringan Enterprise PT. Nusantara Network] - [Pekan 15:    Finalisasi Dokumentasi & Presentasi ] 
## Anggota Kelompok dan Peran 
- **Muhammad Irgie Yanuar (10221022)** - Network Architect  
- **Noviansyah(10231072)** - Network Engineer  
- **Desnita Dwi Putri (10231030)** - Network Services Specialist  
- **Zaidan Ramadhan Arrazy (10221028)** - Security & Documentation Specialist   
## Daftar Isi 
1. [Pendahuluan](#pendahuluan)  
2. [Isi Laporan](#isi-laporan)    
3. [Kendala dan Solusi](#kendala-dan-solusi)  
4. [Kesimpulan](#kesimpulan)  
## **Pendahuluan**  

### **Latar Belakang**  
PT. Nusantara Network merupakan perusahaan di bidang teknologi informasi yang memiliki dua lokasi kantor (pusat dan cabang) dengan total 6 departemen dan server farm. Perusahaan membutuhkan infrastruktur jaringan yang aman, terkelola dengan baik, dan mampu mendukung pertumbuhan bisnis di masa depan. Proyek ini bertujuan untuk merancang solusi jaringan enterprise yang mengintegrasikan seluruh konsep jaringan komputer yang telah dipelajari.

### **Tujuan**  
1. Merancang topologi jaringan yang memenuhi kebutuhan bisnis PT. Nusantara Network  
2. Mengimplementasikan segmentasi jaringan menggunakan VLAN  
3. Menyediakan konektivitas antar-gedung melalui WAN dengan routing dinamis (OSPF)  
4. Menerapkan layanan jaringan (DHCP, DNS, NAT) dan keamanan (ACL)  
5. Membangun dokumentasi teknis yang komprehensif  

### **Ruang Lingkup**  
Proyek mencakup:  
- Perancangan topologi fisik dan logis  
- Pembagian subnet dan pengalamatan IP  
- Konfigurasi VLAN, trunking, dan routing antar-VLAN  
- Implementasi OSPF untuk koneksi WAN antar-gedung  
- Penyediaan layanan DHCP, DNS, dan NAT  
- Penerapan Access Control List (ACL)  
- Pengujian end-to-end dan troubleshooting  
 
## Isi Laporan
## Link Simulasi
Link:  https://drive.google.com/drive/folders/1ReP91DFMtdtHQrbkorsiQO2_4esm8yBS?usp=sharing

## Link Slide Presentasi
Link: https://www.canva.com/design/DAGoCy7c6sc/n6jAAYUzypyGiYNMYk5OMg/edit 

## WEEK 09
## **Analisis Kebutuhan Jaringan**  
### **Infrastruktur Jaringan**  
| Lokasi       | Departemen       | Jumlah Device | Kebutuhan Khusus                  |  
|--------------|------------------|---------------|-----------------------------------|  
| **Gedung A** | IT               | 40 komputer   | Akses ke semua departemen & server|  
|             | Keuangan         | 25 komputer   | Akses terbatas ke SDM & server    |  
|             | SDM              | 20 komputer   | Akses koordinasi ke semua dept    |  
|             | Server Farm      | 10 server     | Keamanan tinggi                   |  
| **Gedung B** | Marketing        | 30 komputer   | Tidak akses Keuangan              |  
|             | Operasional      | 35 komputer   | Akses terbatas ke server          |  

### **Persyaratan Teknis**  
- Setiap departemen dalam VLAN terpisah  
- Bandwidth management untuk koneksi WAN  
- NAT untuk akses internet terpusat  
- DHCP server per VLAN  
- DNS internal/eksternal  
- ACL berdasarkan kebijakan keamanan  

---

## **Timeline Rencana Kerja** 

![Timeline](Timeline.png)

## **Sketsa Desain Jaringan Awal**  
## 1. Gedung A (Kantor Pusat)

Terdapat beberapa departemen yang terhubung dengan switch masing-masing:

- **Departemen IT**  
  - Jumlah user: 40  
  - Terhubung ke: SWITCH-IT

- **Departemen Keuangan**  
  - Jumlah user: 25  
  - Terhubung ke: SWITCH-Keuangan

- **Departemen SDM**  
  - Jumlah user: 20  
  - Terhubung ke: SWITCH-SDM

Setiap switch departemen dihubungkan ke **Router-2**, yang juga terhubung ke:

- **Server Farm**  
  Menyediakan layanan dan aplikasi untuk pengguna internal.

- **Departemen Operasional**  
  Memiliki sejumlah komputer/terminal kerja yang langsung terhubung ke jaringan kantor pusat.

---

## 2. Koneksi Internet & Antar Gedung

- **Router-1** terhubung langsung ke **ISP (Internet Service Provider)** untuk akses internet.
- **Router-1** dan **Router-2** saling terhubung melalui **WAN Link** dengan menggunakan protokol **OSPF (Open Shortest Path First)**.
  - OSPF adalah protokol routing dinamis yang memungkinkan pemilihan rute terbaik antar jaringan.

---

## 3. Gedung B (Kantor Cabang)

Memiliki struktur jaringan yang lebih kecil:

- **SWITCH-Marketing** terhubung ke **SWITCH-Operasional**
- **SWITCH-Operasional** terhubung ke **Departemen Marketing**
  - Jumlah user: 30

Gedung B terhubung ke jaringan kantor pusat melalui **WAN Link (Router-1 ↔ Router-2)**.

---

## 4. Kesimpulan Alur Jaringan

- Setiap departemen dihubungkan melalui switch masing-masing.
- **Router-2** menjadi penghubung utama untuk seluruh perangkat di kantor pusat, server farm, dan akses ke jaringan luar.
- **Router-1** berperan sebagai penghubung ke ISP sekaligus penghubung antar gedung (kantor pusat dan cabang) melalui WAN Link.
- Protokol OSPF digunakan sebagai routing dinamis antar router.

## WEEK 10
#### Router Utama

##### Fungsi dan Peran:
- Router utama adalah komponen inti dari jaringan ini.
- Bertugas melakukan **routing antar VLAN** dan antar **gedung** (A dan B).
- Terhubung langsung ke **cloud** sebagai representasi dari **akses internet** perusahaan.
- Menghubungkan ke **switch layer 2** yang menyambungkan ke seluruh departemen.

Router ini sangat penting karena berfungsi sebagai titik pusat komunikasi antar semua segmen jaringan. Routing antar VLAN dapat dikontrol menggunakan Access Control List (ACL) untuk menentukan siapa yang bisa mengakses apa.

#### Gedung A (Kantor Pusat)

Gedung A menjadi pusat utama pengelolaan sistem dan data internal. Memiliki beberapa departemen yang dipisahkan oleh VLAN untuk keamanan dan efisiensi jaringan.

##### a. Departemen IT
- **VLAN:** 10
- **Perangkat:** 
  - 40 PC (PC-PT 1 sampai PC-PT 40)
  - Terhubung ke satu switch Cisco 2960-24TT
- **Fungsi:**
  - Menjadi jaringan utama pengembangan sistem IT internal.
  - Digunakan untuk pengembangan aplikasi, pengujian, pemrograman, serta pengelolaan sistem backend seperti server atau database.
  
Karena bersifat teknis, departemen ini membutuhkan koneksi stabil, cepat, dan bebas gangguan untuk mendukung proses development.

##### b. Departemen Keuangan
- **VLAN:** 20
- **Perangkat:**
  - 25 PC (K1 sampai K25)
  - Terhubung ke switch khusus VLAN 20
- **Fungsi:**
  - Fokus pada transaksi dan pengelolaan sistem keuangan.
  - Kemungkinan besar terhubung ke server ERP atau database keuangan.
  
Isolasi melalui VLAN sangat penting di sini karena informasi yang ditangani bersifat sensitif dan harus dijaga privasinya.

##### c. Departemen SDM
- **VLAN:** 30
- **Perangkat:**
  - 20 PC (SDM1 sampai SDM20)
  - Terhubung ke switch VLAN 30
- **Fungsi:**
  - Digunakan untuk manajemen data karyawan, absensi, rekrutmen, dan aktivitas administratif SDM lainnya.
  
Departemen ini sering menangani data pribadi, sehingga perlu pembatasan akses dan perlindungan jaringan yang baik.

##### d. Server Farm
- **Terdiri dari:**
  - 1 Switch Cisco
  - 2 Server (Server0 dan Server1)
- **Koneksi:**
  - Terhubung langsung ke router utama
- **Fungsi:**
  - Sebagai pusat layanan dan sumber daya jaringan internal:
    - File server
    - Database server
    - Aplikasi intranet
    - Domain Controller (DC)
- **Keunggulan:**
  - Karena terhubung langsung ke router, server dapat melayani berbagai VLAN sekaligus, tergantung konfigurasi ACL dan routing antar VLAN.

Server farm ini adalah jantung dari jaringan internal yang memungkinkan tiap departemen bekerja dengan sistem terpusat.

#### Gedung B (Kantor Cadangan)

Gedung B memiliki dua departemen besar yang berfokus pada operasional dan pemasaran.

##### a. Departemen Marketing
- **VLAN:** 40
- **Perangkat:**
  - Jumlah tidak disebutkan, tetapi tergolong banyak.
  - Diwakili dalam topologi dengan warna biru untuk menunjukkan keseragaman VLAN.
  - Terhubung ke switch VLAN 40 yang menuju router utama.
- **Fungsi:**
  - Aktivitas pemasaran, pengumpulan data pasar, komunikasi eksternal, dan kampanye digital.
  
Penggunaan VLAN memungkinkan departemen ini beroperasi secara mandiri tanpa mengganggu lalu lintas jaringan internal lainnya.

##### b. Departemen Operasional
- **VLAN:** 50
- **Perangkat:**
  - Banyak PC dengan label kompleks (contoh: PC6(1), PC4(1)(2), dll.)
  - Terhubung ke switch VLAN 50
- **Fungsi:**
  - Digunakan untuk aktivitas utama perusahaan seperti:
    - Entri data produksi
    - Pelayanan pelanggan
    - Pemantauan proses operasional
- **Catatan:**
  - Karena kepadatan perangkat yang tinggi, VLAN ini berpotensi mengalami beban lalu lintas tinggi.
  - Diperlukan konfigurasi **bandwidth management** untuk menjaga performa dan stabilitas jaringan.


#### Departemen Operasional (Tambahan di Bawah Router)

- **Perangkat:**
  - 3 PC: PC0, PC1, dan PC2
  - Terhubung ke switch kecil yang langsung tersambung ke router utama.
- **Fungsi:**
  - Kemungkinan merupakan tim **admin jaringan** atau **helpdesk**.
  - Bertugas untuk:
    - Monitoring jaringan
    - Pemeliharaan sistem harian
    - Troubleshooting perangkat dan koneksi.

Karena berada langsung di bawah router, perangkat ini memiliki akses cepat ke semua VLAN dan server.

#### Kesimpulan

Struktur jaringan PT Nusantara Network dirancang dengan memperhatikan:
- **Segmentasi VLAN** untuk keamanan dan efisiensi.
- **Routing pusat** yang fleksibel dan scalable.
- **Penggunaan switch Layer 2 dan routing Layer 3** untuk pemisahan logis dan pengaturan lalu lintas.
- **Server farm terpusat** untuk mempermudah pengelolaan layanan internal.
- **Bandwidth management dan ACL** sebagai upaya menjaga performa dan keamanan.

Struktur ini mencerminkan sistem jaringan perusahaan modern yang terorganisasi dan siap berkembang.


## Tabel pengalamatan IP (subnet, VLAN ID, gateway, range, dsb). 


| Departemen     | VLAN ID | Jumlah Host | Network Address     | Subnet Mask           | Gateway         | Usable IP Range                   | Broadcast Address   |
|----------------|---------|-------------|----------------------|------------------------|------------------|------------------------------------|---------------------|
| IT             | 10      | 40          | 192.168.10.0/26       | 255.255.255.192 (/26)  | 192.168.10.1     | 192.168.10.2 – 192.168.10.62       | 192.168.10.63       |
| Keuangan       | 20      | 25          | 192.168.10.64/27      | 255.255.255.224 (/27)  | 192.168.10.65    | 192.168.10.66 – 192.168.10.94      | 192.168.10.95       |
| SDM            | 30      | 20          | 192.168.10.96/27      | 255.255.255.224 (/27)  | 192.168.10.97    | 192.168.10.98 – 192.168.10.126     | 192.168.10.127      |
| Marketing      | 40      | 30          | 192.168.10.128/27     | 255.255.255.224 (/27)  | 192.168.10.129   | 192.168.10.130 – 192.168.10.158    | 192.168.10.159      |
| Operasional    | 50      | 35          | 192.168.10.160/26     | 255.255.255.192 (/26)  | 192.168.10.161   | 192.168.10.162 – 192.168.10.222    | 192.168.10.223      |
| Server Farm    | 60      | 10 server   | 192.168.10.224/28     | 255.255.255.240 (/28)  | 192.168.10.225   | 192.168.10.226 – 192.168.10.238    | 192.168.10.239      |



## Daftar perangkat yang dibutuhkan (router, switch, server, dsb). 

| No. | Jenis Perangkat    | Nama/Label di Topologi | Jumlah | Lokasi                                                                 |
|-----|--------------------|-------------------------|--------|------------------------------------------------------------------------|
| 1   | Router             | Router-PT               | 2      | 1 di pusat jaringan (inter-VLAN routing), 1 ke Server Farm             |
| 2   | Switch             | 2960-24TT               | 7      | 1 di Departemen IT, 1 Keuangan, 1 SDM, 1 Marketing, 1 Operasional, 1 Server Farm, 1 Pusat |
| 3   | PC / Client        | PC-PT                   | 125    | Departemen IT (40), Keuangan (25), SDM (20), Marketing (20), Operasional (40) |
| 4   | Server             | Server-PT               | 2      | Server Farm                                                            |
| 5   | Cloud / Internet   | Cloud-PT                | 1      | Paling atas, terkoneksi ke Router-PT pusat (PT Nusantara Network)     |


## Daftar perangkat yang dibutuhkan (router, switch, server, dsb). 

| No. | VLAN ID | Nama VLAN       | Fungsi / Tujuan Lebih Detail                                                                                                                                                       |
|-----|---------|------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1   | 10      | VLAN_IT          | Mengelompokkan seluruh perangkat client milik Departemen IT. VLAN ini digunakan agar lalu lintas IT terpisah dari departemen lain, memungkinkan kontrol akses khusus dan isolasi jaringan untuk kebutuhan teknis (admin, development, support). |
| 2   | 20      | VLAN_KEUANGAN    | Mengelola jaringan perangkat Departemen Keuangan. Memberikan isolasi agar data transaksi dan akses ke server keuangan tidak bisa diakses sembarang user. Biasanya dikombinasikan dengan firewall atau ACL untuk mengontrol akses ke database keuangan. |
| 3   | 30      | VLAN_SDM         | Digunakan oleh Departemen Sumber Daya Manusia (SDM). Menyediakan segmentasi agar komunikasi dan akses data SDM (seperti data karyawan, gaji, absensi) tidak tercampur dengan lalu lintas VLAN lain. |
| 4   | 40      | VLAN_MARKETING   | Menyediakan jaringan khusus untuk Departemen Marketing. Memungkinkan pengaturan bandwidth khusus, pengamanan data riset pemasaran, serta kontrol akses ke aplikasi promosi atau CRM (Customer Relationship Management). |
| 5   | 50      | VLAN_OPERASIONAL | Mengelompokkan seluruh perangkat operasional (misalnya front office, gudang, layanan pelanggan). Dapat diatur memiliki akses terbatas ke aplikasi internal perusahaan sesuai kebutuhan operasional harian. |
| 6   | 99      | VLAN_SERVER      | VLAN khusus untuk Server Farm, berisi perangkat server penting (seperti database, web server, file server). VLAN ini digunakan untuk mengisolasi server dari broadcast VLAN lain, memungkinkan pengamanan jaringan yang lebih ketat dan kontrol penuh atas akses masuk/keluar ke server. Biasanya hanya dapat diakses oleh VLAN tertentu (misal IT/Admin). |


## WEEK 11
### Diagram Topologi 

![topologi](Topologi.jpg)

### Konfigurasi VLAN dan Trunking

#### Konfigurasi Departemen SDM

```
enable
configure terminal
vlan 30
name DEP_SDM
exit

interface range fastEthernet 0/1 - 24
switchport mode access
switchport access vlan 30
```
Kode konfigurasi ini digunakan untuk mengatur switch agar dapat digunakan dengan VLAN yang dirancang khusus untuk Departemen SDM. Langkah pertama yang dilakukan adalah memasuki mode admin (privileged EXEC) melalui perintah enable, kemudian masuk ke mode konfigurasi global menggunakan configure terminal. Setelah itu, VLAN baru dengan ID 30 dibuat melalui perintah vlan 30, dan diberi nama "DEP_SDM" untuk menunjukkan bahwa VLAN tersebut dikhususkan untuk Departemen Sumber Daya Manusia. Setelah VLAN selesai dibuat, port yang ada pada switch perlu dikonfigurasi agar tergabung dalam VLAN tersebut. Hal ini dilakukan dengan memilih rentang port dari FastEthernet 0/1 hingga 0/24 melalui perintah interface range fastEthernet 0/1 - 24. Rentang port yang dipilih kemudian diatur ke mode akses melalui switchport mode access, yang berarti port hanya akan bergabung dengan satu VLAN tertentu. Kemudian, melalui perintah switchport access vlan 30, port tersebut ditambahkan ke VLAN 30 yang baru saja dibuat. 

Hasil dari konfigurasi ini adalah seluruh perangkat yang terhubung ke port FastEthernet 0/1 hingga 0/24 akan menjadi bagian dari VLAN 30 dan dapat saling berkomunikasi secara eksklusif dalam jaringan yang sama. Keuntungan utama dari konfigurasi ini adalah isolasi lalu lintas jaringan Departemen SDM dari departemen lain, sehingga meningkatkan keamanan dan efisiensi dalam pengelolaan jaringan. Konfigurasi ini juga menunjukkan fleksibilitas switch dalam mendukung struktur jaringan yang menggunakan VLAN untuk segmentasi dan pengelolaan jaringan yang lebih baik.
 
#### Konfigurasi Departemen Keuangan
![konfig_switch1_vlan20](konfig_switch1_vlan20.jpg)
Konfigurasi ini bertujuan untuk mengatur switch 1 agar perangkat dari Departemen Keuangan (vlan 20) dapat terhubung dan beroperasi dalam jaringan VLAN 20 yang dibuat khusus untuk mereka. Langkah pertama dalam konfigurasi ini adalah memasuki mode administrasi menggunakan perintah enable, lalu dilanjutkan dengan perintah configure terminal untuk memasuki mode konfigurasi global. Setelah itu, VLAN baru dengan ID 20 dibuat menggunakan perintah vlan 20, dan diberi nama "DEP_KEUANGAN" untuk mempermudah identifikasi VLAN yang dikhususkan untuk jaringan Departemen Keuangan. Kemudian, dengan perintah interface range fastEthernet 0/1 - 24, port dari 0/1 hingga 0/24 pada switch dipilih untuk konfigurasi lebih lanjut. Langkah selanjutnya adalah mengatur mode akses pada port-port tersebut melalui perintah switchport mode access, yang memastikan setiap port hanya akan terhubung ke VLAN tertentu, dalam hal ini VLAN 20. Akhirnya, dengan perintah switchport access vlan 20, port-port tersebut dihubungkan ke VLAN 20. Hasilnya, perangkat-perangkat yang terhubung ke port 0/1 hingga 0/24 pada switch ini akan menjadi bagian dari VLAN 20 dan dapat saling berkomunikasi secara eksklusif di dalam VLAN tersebut. Konfigurasi ini memastikan Departemen Keuangan memiliki jaringan yang terisolasi dan aman dari departemen lain, sehingga meningkatkan efisiensi dan keamanan operasional mereka dalam penggunaan jaringan.


![konfig_switch2_vlan20](konfig_switch2_vlan20.jpg)
Konfigurasi pada switch 2 ini dilakukan untuk menghubungkan perangkat Departemen Keuangan ke VLAN 20, yang dirancang khusus untuk kebutuhan komunikasi jaringan mereka. Pertama, admin jaringan masuk ke mode admin menggunakan perintah enable dan selanjutnya ke mode konfigurasi global dengan perintah conf t. VLAN 20 kemudian dibuat dengan perintah vlan 20 dan diberi nama "DEP_KEUANGAN" untuk memudahkan identifikasi jaringan departemen tersebut. Setelah itu, seluruh port dalam rentang FastEthernet 0/1 hingga 0/24 dipilih menggunakan perintah interface range fastEthernet 0/1 - 24. Seluruh port tersebut diatur ke mode akses menggunakan perintah switchport mode access, yang memastikan bahwa masing-masing port hanya terhubung ke satu VLAN, yaitu VLAN 20. Langkah terakhir adalah mengaitkan port-port tersebut ke VLAN 20 dengan perintah switchport access vlan 20. 
Dengan konfigurasi ini, perangkat yang terhubung ke switch 2 melalui port FastEthernet 0/1 hingga 0/24 akan menjadi bagian dari VLAN 20. Hal ini memastikan komunikasi yang aman dan terisolasi untuk Departemen Keuangan, sehingga mereka dapat bertukar data tanpa gangguan dari departemen lain. Konfigurasi ini juga mendukung segmentasi jaringan yang baik untuk keamanan dan efisiensi operasional.

#### Konfigurasi Departemen IT
![konfig_switch1](konfig_switch1.jpg)
Konfigurasi ini bertujuan untuk mengatur switch 1 agar semua perangkat dalam Departemen IT terhubung ke VLAN 10 dengan nama "DEP_IT". Langkah-langkahnya dimulai dengan masuk ke mode admin (privileged mode) melalui perintah enable, lalu berlanjut ke mode konfigurasi terminal menggunakan configure terminal. Kemudian, VLAN baru dengan ID 10 dibuat menggunakan perintah vlan 10, dan VLAN ini diberi nama "DEP_IT" untuk memudahkan identifikasi jaringan. Setelah VLAN dibuat, konfigurasi dilanjutkan dengan memilih port-port tertentu pada switch menggunakan perintah interface range fastEthernet 0/1 - 24. Port-port ini diatur ke mode akses dengan perintah switchport mode access, yang berarti setiap port hanya akan terhubung ke satu VLAN saja, yaitu VLAN 10. Dengan menggunakan perintah switchport access vlan 10, semua port dalam rentang tersebut dikaitkan ke VLAN 10. 

Hasil akhirnya, perangkat-perangkat yang terhubung ke port FastEthernet 0/1 hingga 0/24 pada switch akan menjadi bagian dari VLAN 10, memungkinkan komunikasi yang eksklusif dan aman antar perangkat dalam Departemen IT, sekaligus memisahkannya dari lalu lintas jaringan departemen lain.

![konfig_switch2](konfig_switch1.jpg)



### Implementasi Routing antar-VLAN
#### Departemen IT
![konfig_trunk](konfig_trunk.jpg)
Pada konfigurasi ini, mode trunk diaktifkan pada port switch untuk memungkinkan komunikasi antara VLAN yang melewati koneksi antar switch. Proses konfigurasi trunk dilakukan dengan mengatur port tertentu pada switch ke mode trunk. Dalam mode ini, port dapat mengirimkan dan menerima data dari berbagai VLAN secara simultan. Misalnya, jika dua switch memiliki VLAN 10, 20, dan 30 yang sama, koneksi trunk memastikan data dari ketiga VLAN tersebut dapat diteruskan dari satu switch ke yang lainnya tanpa hambatan. Dengan konfigurasi ini, jaringan menjadi lebih fleksibel dan scalable, memungkinkan perangkat-perangkat dari VLAN yang sama, tetapi terhubung pada switch yang berbeda, tetap saling berkomunikasi.

#### Departemen Keuangan
![konfig_trunk2](konfig_trunk2.jpg)
Konfigurasi trunk pada kedua switch diperlukan untuk memastikan bahwa VLAN dapat saling berkomunikasi melalui koneksi antar switch. Dimulai dengan masuk ke mode konfigurasi interface yang sesuai, seperti interface gigabitEthernet 0/1, konfigurasi ini mengaktifkan mode trunk melalui perintah switchport mode trunk. Mode trunk memungkinkan interface tersebut untuk membawa lalu lintas dari berbagai VLAN, sehingga komunikasi antar VLAN di kedua switch dapat berjalan dengan lancar. Dengan menggunakan perintah ini pada setiap switch, port GigabitEthernet 0/1 di kedua sisi menjadi trunk, yang berfungsi sebagai jalur utama untuk lalu lintas data dari berbagai VLAN. Perintah ini memastikan bahwa lalu lintas dari VLAN tertentu tidak dibatasi hanya pada satu switch tetapi dapat diteruskan ke switch lainnya.


#### Departemen SDM
```
enable
conf t

vlan 50
name OPERASIONAL
exit

interface range FastEthernet 0/1 - 24
switchport mode access
switchport access vlan 50
exit
```
Konfigurasi VLAN 50 pada switch OPERASIONAL dilakukan untuk mengelompokkan perangkat-perangkat jaringan ke dalam satu segmen logis, yaitu VLAN dengan nama "OPERASIONAL". Proses konfigurasi diawali dengan masuk ke mode konfigurasi global menggunakan perintah enable dan conf t. Selanjutnya, VLAN dengan ID 50 dibuat menggunakan perintah vlan 50 dan diberi nama "OPERASIONAL" melalui perintah name OPERASIONAL. Setelah VLAN terbentuk, konfigurasi dilanjutkan dengan menetapkan port-port yang akan dimasukkan ke dalam VLAN tersebut. Dalam hal ini, digunakan perintah interface range FastEthernet 0/1 - 24 untuk memilih port dari FastEthernet 0/1 hingga 0/24. Setiap port dikonfigurasi sebagai access port menggunakan perintah switchport mode access, yang berarti hanya mendukung satu VLAN saja. Kemudian, port-port tersebut di-assign ke VLAN 50 dengan perintah switchport access vlan 50. Konfigurasi ini memungkinkan perangkat yang terhubung ke port 0/1 sampai 0/24 untuk saling berkomunikasi dalam satu VLAN, sehingga komunikasi antar departemen bisa dipisahkan secara logis untuk meningkatkan keamanan dan efisiensi jaringan.


## WEEK 12
### Konfigurasi Routing Statis pada Jaringan Intra-gedung.

![Konfigurasi Statis](konfstatis.jpg)

Konfigurasi pada gambar tersebut menunjukkan proses pengaturan sebuah router Cisco untuk menghubungkan beberapa jaringan VLAN menggunakan metode yang disebut Router-on-a-Stick. Router-on-a-Stick adalah teknik yang memungkinkan satu port fisik pada router menangani lalu lintas dari beberapa VLAN melalui sub-interface. Ini sangat berguna untuk menghubungkan beberapa jaringan yang terpisah secara logis (VLAN) tetapi masih menggunakan infrastruktur fisik yang sama, seperti dalam kasus penghubungan antar departemen dalam satu gedung, atau bahkan antar gedung yang terpisah secara fisik namun tetap dalam satu sistem jaringan. Dalam konfigurasi tersebut, administrator pertama-tama masuk ke mode konfigurasi global (conf t), lalu membuat sub-interface pada interface fisik FastEthernet0/0, yaitu FastEthernet0/0.40 dan FastEthernet0/0.50. Masing-masing sub-interface diberi konfigurasi encapsulation dot1Q, yang merupakan standar untuk menandai lalu lintas VLAN pada jaringan Ethernet, dengan nomor VLAN 40 dan 50. Setelah itu, tiap sub-interface diberikan alamat IP (192.168.40.1 dan 192.168.50.1) sebagai gateway untuk masing-masing VLAN. IP ini berfungsi sebagai alamat yang akan digunakan oleh perangkat klien dalam VLAN tersebut untuk mengirim data keluar dari jaringan lokal mereka.

Setelah konfigurasi sub-interface selesai, router menyimpan konfigurasi ke dalam memori agar tetap aktif meskipun router dimatikan atau direstart. Kemudian, administrator menjalankan perintah show ip route untuk melihat routing table, yaitu daftar jaringan yang dikenali dan bisa dijangkau oleh router. Output-nya menunjukkan bahwa router telah mengenali beberapa jaringan yang “directly connected” (langsung terhubung) melalui sub-interface FastEthernet0/0.40 dan 0.50, yaitu jaringan 192.168.40.0/24 dan 192.168.50.0/24. Ini menandakan bahwa router telah berhasil menghubungkan VLAN 40 dan VLAN 50. Dengan konfigurasi ini, router memungkinkan komunikasi antar perangkat yang berada di VLAN berbeda, sehingga pengguna di gedung atau ruangan berbeda, misalnya gedung sebelah yang dapat saling bertukar data meskipun mereka berada dalam VLAN yang berbeda. Semua data dari berbagai VLAN akan melewati satu kabel trunk menuju router, dan router akan meneruskannya sesuai dengan VLAN ID dan alamat IP tujuan.


![Konfigurasi Statis2](konfstatis2.jpg)

Konfigurasi ini pada sebuah switch untuk mengatur VLAN 50 yang dinamai “OPERASIONAL”. VLAN (Virtual Local Area Network) digunakan untuk membagi jaringan fisik menjadi beberapa jaringan logis. Dalam kasus ini, VLAN 50 digunakan khusus untuk gedung Operasional, sehingga semua perangkat di gedung tersebut tergabung dalam jaringan VLAN 50 agar bisa berkomunikasi hanya dengan perangkat lain di VLAN yang sama, meskipun terkoneksi ke switch yang sama.

Pada awalnya, muncul error saat mencoba membuat VLAN karena perintah vlan 50 diberikan di mode yang salah (harusnya di mode konfigurasi global). Setelah masuk ke mode konfigurasi dengan conf t, VLAN 50 berhasil dibuat dan diberi nama “OPERASIONAL” menggunakan perintah name OPERASIONAL. Lalu, interface FastEthernet0/1 dikonfigurasi sebagai trunk. Trunk port ini penting karena berfungsi untuk mengirimkan trafik dari berbagai VLAN melalui satu kabel ke perangkat lain seperti router atau switch lain. Ini artinya FastEthernet0/1 menghubungkan switch ini ke router (atau ke switch lain) agar VLAN 50 bisa berkomunikasi ke luar gedung jika diperlukan.

Kemudian, interface FastEthernet0/2 sampai 0/24 dikonfigurasi sebagai access port, yang berarti port tersebut hanya akan membawa satu VLAN, dalam hal ini VLAN 50. Perintah switchport access vlan 50 memastikan bahwa semua perangkat yang terhubung ke port-port itu akan otomatis masuk ke jaringan VLAN 50, yaitu jaringan khusus untuk gedung operasional.

Secara sederhana, konfigurasi ini bertujuan agar seluruh perangkat di gedung Operasional bisa saling berkomunikasi dalam satu jaringan terisolasi (VLAN 50), dan melalui port trunk, jaringan tersebut juga bisa terhubung ke jaringan pusat atau router untuk akses ke jaringan lain jika diperlukan. Output yang muncul seperti "LINEPROTO-5-UPDOWN" menunjukkan bahwa port yang diaktifkan sedang mengalami perubahan status koneksi (naik atau turun), yang umum terjadi saat konfigurasi baru diterapkan.

![Konfigurasi Statis3](konfstatis3.jpg)

VLAN 50 dibuat dan diberi nama “OPERASIONAL”. Kemudian, port FastEthernet0/1 dikonfigurasi sebagai trunk dengan perintah switchport mode trunk, yang artinya port ini akan membawa trafik dari beberapa VLAN, termasuk VLAN 50. Trunking diperlukan agar VLAN 50 dari switch ini bisa berkomunikasi dengan VLAN 50 dari switch atau router lain. Namun, perlu diperhatikan bahwa tidak ada perintah eksplisit untuk mengatur native VLAN, sehingga kemungkinan besar switch masih menggunakan default native VLAN 1, yang menyebabkan ketidaksesuaian dengan sisi lain yang menggunakan VLAN 40 sebagai native.

Selanjutnya, port FastEthernet0/2 hingga FastEthernet0/12 dikonfigurasi sebagai access port, artinya masing-masing port hanya akan digunakan oleh satu perangkat dan akan masuk ke dalam VLAN 50 secara otomatis. Ini dilakukan dengan perintah switchport mode access dan switchport access vlan 50, yang memastikan semua perangkat yang dicolokkan ke port-port tersebut langsung tergabung dalam jaringan gedung Operasional (VLAN 50). Secara keseluruhan, konfigurasi ini bertujuan untuk membentuk dan mengelola VLAN 50 khusus untuk gedung Operasional agar perangkat di dalamnya dapat berkomunikasi dalam satu jaringan.

### Implementasi Routing Dinamis (OSPF) untuk Koneksi Antar-gedung. 
 
 ![Konfigurasi dinamis](konfdinamis.jpg)

Konfigurasi ini dilakukan untuk mengelompokkan port-port tertentu di switch ke dalam satu jaringan VLAN, sehingga perangkat seperti komputer atau printer yang terhubung ke port-port tersebut bisa saling berkomunikasi seolah-olah berada di jaringan yang sama, walaupun mungkin tersebar secara fisik di tempat yang berbeda. Dalam hal ini, VLAN 40 digunakan dan dinamai "MARKETING", yang menunjukkan bahwa VLAN ini ditujukan untuk departemen Marketing.

Langkah pertama adalah masuk ke mode konfigurasi menggunakan perintah enable dan conf t. Setelah itu, dibuat VLAN 40 dan diberi nama "MARKETING" agar mudah dikenali. Port FastEthernet0/1 dikonfigurasi sebagai trunk, yaitu jalur utama yang bisa membawa data dari banyak VLAN sekaligus, termasuk VLAN 40. Port trunk ini biasanya digunakan untuk menghubungkan antar switch, agar VLAN yang sama bisa digunakan di beberapa switch yang berbeda.

Kemudian, port FastEthernet0/2 sampai 0/24 disetel sebagai access port, yang artinya masing-masing port hanya mendukung satu VLAN saja, yaitu VLAN 40. Jadi, setiap perangkat yang dicolokkan ke port-port ini otomatis akan menjadi bagian dari VLAN MARKETING. Ini membuat jaringan jadi lebih rapi, aman, dan efisien, karena perangkat dari departemen lain tidak bisa mengakses VLAN ini secara langsung.

Dengan cara ini, seluruh perangkat yang tergabung di VLAN 40 (MARKETING) bisa saling terkoneksi dalam satu jaringan logis yang sama, meskipun secara fisik mereka bisa tersebar di tempat atau ruangan berbeda. Ini merupakan praktik umum dalam pengelolaan jaringan di kantor atau organisasi besar.

### Simulasi Koneksi WAN Antar Gedung.

![Simuasi WAN](simulasi.jpg)

Gambar ini menunjukkan hasil pengiriman paket ICMP (Internet Control Message Protocol), yang dalam konteks ini digunakan untuk melakukan tes koneksi (ping) antar perangkat dalam jaringan. Setiap baris di tabel menunjukkan satu simulasi pengiriman paket dari satu perangkat (source) ke perangkat lain (destination), dengan status “Successful” yang berarti paket berhasil dikirim dan diterima tanpa hambatan. Misalnya, pada baris pertama, paket ICMP berhasil dikirim dari KC1 ke KC2, sedangkan pada baris lainnya juga terlihat keberhasilan pengiriman antara berbagai pasangan perangkat lain seperti KC30 ke KC29, SDM 1 ke SDM 20, dan seterusnya. Kolom “Type” menunjukkan bahwa semua paket bertipe ICMP, dan “Time(sec)” yang bernilai 0.000 menandakan bahwa simulasi ini dilakukan sangat cepat, hampir tanpa delay, yang umum terjadi di simulasi digital.

Keberhasilan semua paket ICMP ini merupakan indikator penting bahwa jaringan telah dikonfigurasi dengan benar, termasuk alamat IP, subnet, pengaturan VLAN, trunking antar switch, dan pengaturan routing (baik routing antar VLAN maupun routing antar jaringan berbeda). Artinya, perangkat-perangkat yang berada dalam satu gedung maupun antar gedung sudah dapat saling terhubung secara logis. Ini juga menunjukkan bahwa konfigurasi baik di switch (seperti VLAN dan port access/trunk), router (subinterface, routing), maupun pengalamatan IP sudah sinkron dan tidak terdapat konflik.

#### Tabel routing pada router utama dengan penjelasan detail

![Table Routering](tabel.jpg)

show ip route adalah perintah yang digunakan untuk menampilkan tabel routing, yaitu daftar semua jaringan yang dikenal oleh router beserta informasi tentang bagaimana dan melalui interface mana router dapat menjangkau jaringan-jaringan tersebut. Dalam konteks gambar ini, router menunjukkan bahwa ia mengenal enam jaringan lokal dengan subnet berbeda, yang semuanya secara langsung terhubung melalui antarmuka FastEthernet dengan subinterface yang berbeda. Setiap baris dimulai dengan huruf C, yang berarti “Connected”, menandakan bahwa jaringan tersebut terhubung langsung dengan router, tanpa harus melalui router lain atau menggunakan protokol routing seperti OSPF, EIGRP, atau RIP. Misalnya, jaringan 192.168.1.0/24 terhubung melalui antarmuka fisik FastEthernet0/0, sementara jaringan 192.168.10.0/24 hingga 192.168.50.0/24 terhubung melalui subinterface FastEthernet0/0.10 hingga FastEthernet0/0.50. Subinterface ini biasanya digunakan dalam skenario router-on-a-stick, di mana satu port fisik router dibagi menjadi beberapa subinterface logis, masing-masing dikonfigurasi dengan IP dari VLAN berbeda. Ini menandakan bahwa router tersebut sedang digunakan untuk menghubungkan beberapa VLAN (seperti VLAN 10, 20, 30, 40, dan 50), yang biasanya berasal dari switch yang sudah dikonfigurasi menggunakan 802.1Q trunking.

#### Analisis performa routing dinamis vs statis
| **Aspek**              | **Routing Statis**                                                                                 | **Routing Dinamis (OSPF)**                                                                                  |
|-------------------------|---------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------|
| **Cara kerja**         | Admin harus masukkan rute satu per satu secara manual.                                              | Router berbagi info rute otomatis dengan router lain.                                                       |
| **Cocok untuk**        | Jaringan kecil, jarang berubah.                                                                    | Jaringan besar, sering berubah, atau banyak gedung.                                                         |
| **Kalau ada perubahan**| Tidak otomatis, harus diubah manual.                                                               | Otomatis, router menyesuaikan sendiri.                                                                     |
| **Beban kerja router** | Ringan, tidak ada beban tambahan dari protokol.                                                    | Ada sedikit beban tambahan karena pertukaran info antar-router.                                             |
| **Kemudahan**          | Mudah kalau jaringannya kecil.                                                                    | Lebih mudah untuk jaringan besar karena tidak perlu atur rute satu-satu.                                    |
| **Kekuatan**          | Sederhana, hemat sumber daya.                                                                     | Lebih pintar, bisa atur jalur terbaik dan ada backup kalau jalur utama gagal.                              |
| **Kelemahan**         | Repot kalau jaringan besar, rawan salah input.                                                     | Perlu router yang lebih kuat, pengaturan awal lebih rumit.                                                  |
| **Contoh penggunaan** | Hubungkan VLAN di satu gedung pakai Router-on-a-Stick.                                             | Hubungkan jaringan antar gedung pakai OSPF.                                                                |


## WEEK 13
### Konfigurasi DHCP Server untuk Setiap Departemen.

1. Departemen IT
![Konfigurasi DHCP](dhcp-vlan10.jpg)
Pertama, perintah Router>en digunakan untuk masuk ke mode enable pada router. Setelah itu, perintah Router#conf t digunakan untuk masuk ke mode konfigurasi terminal, di mana pengguna dapat melakukan perubahan pada pengaturan router. Selanjutnya, perintah Router(config)#ip dhcp pool IT_POOL dibuat untuk menciptakan sebuah pool DHCP bernama "IT_POOL", yang akan digunakan untuk memberikan alamat IP secara otomatis kepada perangkat yang terhubung.

Dalam konfigurasi DHCP, pengguna menentukan jaringan yang digunakan dengan perintah Router(dhcp-config)#network 192.168.10.0 255.255.255.0, yang menetapkan jaringan 192.168.10.0 dengan subnet mask 255.255.255.0. Untuk memastikan perangkat yang terhubung mendapatkan alamat gateway yang benar, digunakan Router(dhcp-config)#default-router 192.168.10.1, yang menetapkan 192.168.10.1 sebagai default router. Kemudian, alamat server DNS juga diberikan dengan perintah Router(dhcp-config)#dns-server 192.168.100.1, sehingga perangkat dapat melakukan pencarian nama domain. Setelah selesai mengatur DHCP, pengguna keluar dari mode konfigurasi dengan perintah Router(dhcp-config)#exit.

Pada tahap berikutnya, pengguna mengkonfigurasi VLAN dengan perintah Router(config)#interface vlan 10, yang berarti mereka sedang mengatur interface VLAN 10. Alamat IP diberikan dengan Router(config-if)#ip address 192.168.10.1 255.255.255.0, menetapkan IP 192.168.10.1 dengan subnet mask 255.255.255.0. Namun, muncul pesan kesalahan % 192.168.10.0 overlaps with GigabitEthernet0/0.10, yang mengindikasikan bahwa jaringan 192.168.10.0 bertabrakan dengan jaringan yang telah dikonfigurasi pada interface lain. Untuk mengaktifkan interface VLAN 10, digunakan perintah Router(config-if)#no shutdown, lalu pengguna keluar dari konfigurasi interface dengan Router(config-if)#exit.Secara keseluruhan, konfigurasi ini bertujuan untuk menyediakan layanan DHCP serta mengelola jaringan VLAN pada router. Berikut adalah hasilnya.

![Berhasil](berhasil-vlan10.jpg)

2. Departemen Keuangan
![Konfigurasi DHCP](dhcp-vlan20.jpg)
Pertama-tama masuk ke mode konfigurasi dengan perintah en dan conf t, yang memungkinkan mereka mengubah pengaturan router. Kemudian, mereka membuat pool DHCP bernama "KEUANGAN_POOL" untuk memberikan alamat IP secara otomatis kepada perangkat dalam jaringan. Dalam konfigurasi ini, jaringan yang digunakan adalah 192.168.20.0 dengan subnet mask 255.255.255.0, sehingga semua perangkat yang terhubung akan mendapatkan alamat dalam rentang tersebut. Untuk memastikan komunikasi yang lancar, router juga diatur sebagai gateway dengan IP 192.168.20.1. Selain itu, server DNS yang digunakan adalah 192.168.100.10, yang membantu perangkat dalam pencarian nama domain. Nama domain jaringan ditetapkan sebagai "nusantara.local" agar lebih mudah dikenali oleh perangkat yang ada di dalam jaringan.

Setelah selesai mengatur DHCP, pengguna mengonfigurasi VLAN dengan memilih interface VLAN 20. VLAN ini diberi alamat IP 192.168.20.1, yang sesuai dengan konfigurasi sebelumnya. Untuk memastikan VLAN berfungsi dengan baik, pengguna menjalankan perintah no shutdown, yang mengaktifkan interface tersebut. Setelah selesai, mereka keluar dari mode konfigurasi dan kembali ke tampilan utama router. Secara keseluruhan, konfigurasi ini bertujuan untuk memastikan jaringan berfungsi dengan baik dan perangkat dapat terhubung dengan mudah menggunakan alamat IP yang diberikan secara otomatis oleh DHCP, serta memiliki manajemen jaringan yang lebih terstruktur melalui VLAN.


1. Departemen SDM
![Konfigurasi DHCP](dhcp-vlan30.jpg)
Pertama-tama masuk ke mode konfigurasi dengan perintah en dan conf t, yang memungkinkan mereka mengubah pengaturan router. Setelah itu, mereka membuat pool DHCP bernama "SDM_POOL" untuk memberikan alamat IP secara otomatis kepada perangkat yang terhubung dalam jaringan. Jaringan yang digunakan adalah 192.168.30.0 dengan subnet mask 255.255.255.0, sehingga semua perangkat mendapatkan alamat dalam rentang tersebut. Agar komunikasi berjalan lancar, gateway default ditetapkan sebagai 192.168.30.1. Selain itu, server DNS yang digunakan adalah 192.168.100.10, yang akan membantu perangkat dalam pencarian nama domain. Nama domain jaringan diatur sebagai "nusantara.local" untuk memberi identitas yang jelas pada jaringan ini.

Setelah selesai mengatur DHCP, pengguna mengonfigurasi VLAN dengan memilih interface VLAN 30. Interface ini diberikan alamat IP 192.168.30.1, yang sesuai dengan pengaturan gateway pada DHCP. Agar VLAN dapat berfungsi, perintah no shutdown digunakan untuk mengaktifkan interface tersebut. Setelah konfigurasi selesai, pengguna keluar dari mode konfigurasi dan kembali ke tampilan utama router. Secara keseluruhan, konfigurasi ini bertujuan untuk memastikan perangkat dapat terhubung dengan mudah menggunakan alamat IP yang diberikan otomatis oleh DHCP serta memiliki manajemen jaringan yang lebih terstruktur melalui VLAN.


1. Departemen Marketing
![Konfigurasi DHCP](dhcp-vlan40.jpg)
Pertama-tama masuk ke mode konfigurasi dengan perintah en dan conf t, sehingga mereka dapat melakukan pengaturan pada router. Kemudian, mereka membuat pool DHCP bernama "SDM_POOL" untuk membagikan alamat IP secara otomatis kepada perangkat yang terhubung dalam jaringan. Jaringan yang digunakan adalah 192.168.30.0 dengan subnet mask 255.255.255.0, sehingga semua perangkat mendapatkan alamat dalam rentang tersebut. Agar komunikasi berjalan lancar, gateway default ditetapkan sebagai 192.168.30.1. Selain itu, server DNS yang digunakan adalah 192.168.100.10, yang membantu perangkat dalam pencarian nama domain. Nama domain jaringan diatur sebagai "nusantara.local" untuk memberikan identitas yang jelas pada jaringan ini.

Setelah selesai mengatur DHCP, pengguna mengonfigurasi VLAN dengan memilih interface VLAN 30. Interface ini diberikan alamat IP 192.168.30.1, yang sesuai dengan pengaturan gateway dalam DHCP. Agar VLAN dapat berfungsi, perintah no shutdown digunakan untuk mengaktifkan interface tersebut. Setelah konfigurasi selesai, pengguna keluar dari mode konfigurasi dan kembali ke tampilan utama router. Secara keseluruhan, konfigurasi ini bertujuan untuk memastikan perangkat dapat terhubung dengan mudah menggunakan alamat IP yang diberikan otomatis oleh DHCP serta memiliki manajemen jaringan yang lebih terstruktur melalui VLAN.

![Berhasil](berhasil-vlan40.jpg)

5. Departemen Operasional
![Konfigurasi DHCP](dhcp-vlan50.jpg)
Pertama-tama masuk ke mode konfigurasi dengan perintah en dan conf t, yang memungkinkan untuk melakukan perubahan pada pengaturan router. Kemudian, membuat pool DHCP bernama "SDM_POOL" yang akan digunakan untuk memberikan alamat IP secara otomatis kepada perangkat dalam jaringan. Jaringan yang digunakan adalah 192.168.30.0 dengan subnet mask 255.255.255.0, sehingga semua perangkat yang terhubung akan mendapatkan alamat IP dari rentang ini. Agar komunikasi berjalan lancar, gateway default ditetapkan sebagai 192.168.30.1, yang akan berfungsi sebagai pintu akses utama menuju jaringan lain. Selain itu, server DNS yang digunakan adalah 192.168.100.10, yang membantu perangkat dalam pencarian nama domain. Nama domain jaringan diatur sebagai "nusantara.local" untuk memberikan identitas yang jelas bagi jaringan ini.

Setelah selesai mengatur DHCP, pengguna mengonfigurasi VLAN dengan memilih interface VLAN 30. Interface ini diberikan alamat IP 192.168.30.1, yang sesuai dengan pengaturan gateway dalam DHCP sebelumnya. Agar VLAN dapat berfungsi dengan baik, perintah no shutdown digunakan untuk mengaktifkan interface tersebut. Setelah konfigurasi selesai, pengguna keluar dari mode konfigurasi dan kembali ke tampilan utama router. Secara keseluruhan, konfigurasi ini bertujuan untuk memastikan perangkat dalam jaringan dapat terhubung dengan mudah menggunakan alamat IP yang diberikan secara otomatis oleh DHCP serta memiliki manajemen jaringan yang lebih terstruktur melalui VLAN.


### Implementasi DNS Server untuk Resolusi Nama Internal.
![Konfigurasi DNS](konfDNS.jpg)

Perintah ping 192.168.100.2 digunakan untuk menguji koneksi ke alamat IP tersebut dan berhasil mendapatkan balasan dengan waktu respons yang sangat cepat. Tidak ada paket yang hilang dalam proses ini, menunjukkan bahwa komunikasi antara perangkat berjalan lancar tanpa gangguan jaringan. Selanjutnya, perintah nslookup server.ptnusantara.local digunakan untuk mencari alamat IP yang terkait dengan nama domain server.ptnusantara.local melalui layanan DNS. Hasil yang diperoleh menunjukkan bahwa server DNS yang digunakan terdeteksi sebagai 255.255.255.255, yang mungkin mengindikasikan bahwa sistem menggunakan konfigurasi default atau belum sepenuhnya dikonfigurasi. Namun, perintah ini berhasil menemukan bahwa server.ptnusantara.local memiliki alamat IP 192.168.100.2, yang berarti pencarian nama domain berfungsi dengan baik. Secara keseluruhan, hasil ini menunjukkan bahwa koneksi ke server dapat dilakukan dengan baik, tetapi pengaturan DNS mungkin perlu diperiksa lebih lanjut untuk memastikan konfigurasi jaringan berjalan optimal.

### Konfigurasi NAT untuk Akses Internet.
![Konfigurasi NAT](konfNAT.jpg)
Pada konfigurasi dimulai dengan masuk ke mode konfigurasi menggunakan perintah en dan conf t. Selanjutnya, pengguna membuat Access Control List (ACL) nomor 1, yang mengizinkan jaringan 192.168.0.0/16 untuk menggunakan NAT. Interface GigabitEthernet 0/2 ditetapkan sebagai outside dengan perintah ip nat outside, yang berarti interface ini akan berfungsi sebagai jalur keluar ke internet atau jaringan eksternal. Kemudian, interface GigabitEthernet 0/0 dikonfigurasi sebagai inside menggunakan ip nat inside, sehingga interface ini berfungsi sebagai jalur masuk dari jaringan lokal. Setelah itu, NAT dinamis dikonfigurasi dengan NAT Overload (PAT - Port Address Translation) menggunakan perintah ip nat inside source list 1 interface gigabitEthernet 0/2 overload, yang memungkinkan banyak perangkat dalam jaringan lokal berbagi satu alamat IP publik saat mengakses internet. Setelah konfigurasi selesai, pengguna keluar dari mode konfigurasi dengan perintah exit. Dengan pengaturan ini, router dapat menerjemahkan alamat IP lokal ke alamat IP publik, memungkinkan perangkat dalam jaringan untuk terhubung ke internet dengan cara yang lebih efisien dan terstruktur.

![Konfigurasi NAT](ping-nat.jpg)
Dari perintah ping yang digunakan untuk menguji koneksi ke alamat IP 8.8.8.8, yang merupakan server DNS publik milik Google. Hasilnya menunjukkan bahwa semua paket yang dikirim berhasil diterima kembali tanpa ada yang hilang (0% packet loss), yang berarti koneksi berjalan dengan baik. Dengan hasil ini, dapat dipastikan bahwa koneksi internet bekerja dengan normal tanpa gangguan, sehingga perangkat dapat berkomunikasi dengan server DNS dengan lancar.

## WEEK 14
### Implementasi Access Control List (ACL) Sesuai Kebijakan Keamanan. 

![Konfigurasi ACL](konfACL.jpg)

Konfigurasi Access Control List (ACL) pada gambar berfungsi untuk mengatur akses jaringan berdasarkan VLAN dan alamat IP, sehingga setiap departemen atau bagian dalam jaringan memiliki batasan akses sesuai dengan kebutuhannya. ACL ini membantu mengamankan jaringan dengan memastikan bahwa hanya perangkat atau pengguna yang berwenang dapat mengakses sumber daya tertentu.

Misalnya, VLAN 10 yang digunakan oleh departemen IT diizinkan untuk mengakses semua tujuan tanpa batasan. Hal ini dilakukan dengan menambahkan aturan yang mengizinkan semua lalu lintas dari jaringan 192.168.10.0/24 ke berbagai tujuan. Di sisi lain, VLAN 20 yang digunakan oleh departemen Finance hanya boleh mengakses server di ruang server dengan aturan yang secara spesifik mengizinkan akses ke jaringan 192.168.100.0/24, sementara lalu lintas lainnya ditolak. Hal yang sama berlaku untuk VLAN 30 yang digunakan oleh bagian SOM, di mana aksesnya dibatasi agar hanya bisa mengakses internet, dengan aturan yang mencegah koneksi ke jaringan internal tetapi tetap mengizinkan komunikasi dengan jaringan eksternal. Untuk VLAN 40 yang digunakan oleh Marketing, konfigurasi ACL membatasi aksesnya hanya ke departemen Finance, memastikan bahwa informasi penting hanya dapat diakses oleh mereka yang berkepentingan. Sedangkan VLAN 50 yang digunakan oleh bagian Operational memiliki aturan yang lebih ketat, hanya mengizinkan akses ke layanan tertentu seperti DNS (port UDP 53) dan HTTP (port TCP 80) ke server yang ditentukan, sementara semua jenis koneksi lainnya diblokir. Dengan cara ini, konfigurasi ACL membantu membangun jaringan yang lebih aman dan terstruktur, memastikan bahwa setiap departemen atau pengguna hanya memiliki akses yang diperlukan untuk menjalankan tugasnya, serta mencegah akses yang tidak diinginkan ke sumber daya jaringan lainnya.

![Pemasangan ACL](pemasanganACL.jpg)

Pemasangan Access Control List (ACL) 100 ke semua interface bertujuan untuk mengontrol lalu lintas jaringan secara keseluruhan. Dengan menerapkan ACL ini, setiap VLAN atau bagian dalam jaringan akan memiliki aturan akses yang sesuai dengan kebutuhannya, sehingga keamanan dan efisiensi dalam penggunaan jaringan dapat terjamin.

Proses konfigurasi dimulai dengan menentukan aturan dalam ACL 100, seperti mengizinkan atau menolak akses berdasarkan alamat IP dan port tertentu. Setelah aturan ini dibuat, langkah berikutnya adalah menerapkannya ke semua interface yang ada di router. Pada perangkat jaringan Cisco, ACL dapat diterapkan pada interface dengan perintah seperti ip access-group 100 in atau ip access-group 100 out, yang berarti bahwa aturan ACL akan digunakan untuk lalu lintas yang masuk ke atau keluar dari interface tersebut. Misalnya, jika ada interface yang terhubung ke VLAN 10 untuk departemen IT, kita akan menerapkan ACL agar mereka dapat mengakses semua sumber daya jaringan tanpa pembatasan. Sementara itu, untuk VLAN 20 yang digunakan oleh departemen Finance, ACL diterapkan untuk memastikan mereka hanya dapat mengakses server di ruang server, tetapi tidak ke bagian lain dalam jaringan. Aturan serupa dibuat untuk VLAN lainnya, seperti VLAN 30 untuk bagian SOM yang hanya boleh mengakses internet, VLAN 40 untuk Marketing yang hanya boleh berkomunikasi dengan Finance, dan VLAN 50 untuk Operational yang hanya diperbolehkan menggunakan layanan DNS dan HTTP.

Dengan menerapkan ACL ini ke semua interface, setiap bagian dalam jaringan memiliki batasan akses yang jelas, sehingga data lebih terlindungi dari akses yang tidak diinginkan. Hal ini juga membantu dalam pengelolaan bandwidth dan memastikan bahwa setiap perangkat hanya berkomunikasi dengan tujuan yang diperbolehkan.

### Pengujian Menyeluruh Semua Fitur Jaringan. 
![Uji Akses Server](ujiakses-server.jpg)

Pengujian akses server dilakukan untuk memastikan bahwa aturan yang telah dikonfigurasi dalam Access Control List (ACL) berjalan sesuai dengan yang diharapkan. Dalam konteks jaringan ini, setiap VLAN memiliki batasan akses tertentu, sehingga penting untuk melakukan pengujian guna memastikan perangkat-perangkat dalam VLAN hanya dapat berkomunikasi dengan tujuan yang telah ditentukan.

Langkah pertama dalam pengujian akses server adalah melakukan koneksi dari setiap VLAN ke server yang seharusnya bisa diakses. Misalnya, dari VLAN Finance kita mencoba melakukan ping atau mengakses layanan dari Server Room. Jika koneksi berhasil, maka aturan ACL telah berjalan dengan baik. Namun, jika tidak bisa terhubung, kita perlu memeriksa aturan ACL untuk memastikan bahwa alamat IP yang digunakan sesuai dengan konfigurasi yang telah ditetapkan. Selanjutnya, kita juga menguji apakah VLAN yang memiliki batasan akses benar-benar terblokir dari sumber yang tidak diizinkan. Sebagai contoh, VLAN Marketing hanya boleh mengakses Finance, maka kita bisa mencoba melakukan koneksi dari Marketing ke jaringan lain yang seharusnya tidak bisa diakses, seperti ke VLAN SOM atau Operational. Jika koneksi gagal, itu berarti aturan ACL bekerja sebagaimana mestinya dalam membatasi akses.

Selain itu, pengujian akses dilakukan dengan melihat apakah protokol tertentu seperti HTTP dan DNS telah diterapkan dengan benar untuk VLAN Operational. Jika VLAN ini hanya diizinkan mengakses layanan DNS dan HTTP ke server tertentu, kita bisa mencoba mengakses situs web atau melakukan pencarian DNS dari dalam VLAN ini. Jika akses berjalan lancar sesuai aturan, maka konfigurasi ACL telah diterapkan dengan benar. Terakhir, setelah seluruh pengujian dilakukan, kita bisa memeriksa log dan statistik router untuk memastikan bahwa aturan ACL tidak menyebabkan gangguan yang tidak diinginkan terhadap lalu lintas jaringan. Jika ditemukan anomali seperti akses yang seharusnya diblokir tetapi berhasil dilakukan, maka konfigurasi perlu ditinjau ulang dan diperbaiki.

![Blok IP](blok-ip.jpg)

Untuk memblokir komunikasi antara VLAN 30 dan VLAN 20, kita menggunakan Access Control List (ACL) yang memastikan bahwa perangkat dalam VLAN 30 tidak dapat mengakses perangkat di VLAN 20. Hal ini penting untuk menjaga isolasi jaringan dan memastikan bahwa hanya lalu lintas yang diizinkan yang dapat melewati aturan ACL. Setelah aturan deny ini diterapkan, kita juga perlu memastikan bahwa ada aturan yang tetap mengizinkan lalu lintas lain yang diperlukan untuk operasional jaringan. Oleh karena itu, setelah menambahkan aturan pemblokiran, kita dapat menambahkan aturan untuk mengizinkan lalu lintas yang sesuai, misalnya membolehkan VLAN 30 mengakses internet atau tujuan lain yang dibutuhkan. Terakhir, pengujian perlu dilakukan untuk memastikan bahwa konfigurasi ACL berjalan dengan benar. Pengujian ini bisa dilakukan dengan mencoba melakukan koneksi dari perangkat VLAN 30 ke VLAN 20 dan memeriksa apakah koneksi tersebut benar-benar terblokir. Jika berhasil diblokir, maka konfigurasi ACL telah diterapkan dengan baik dan jaringan lebih terstruktur serta aman sesuai dengan kebutuhannya.

![Cek ACL](cek-acl.jpg)

Pada ping pertama, terlihat bahwa aturan ACL telah diterapkan, yang menyebabkan blokir akses dari VLAN tertentu ke VLAN lainnya sesuai konfigurasi yang telah dibuat. Misalnya, jika ada aturan yang secara spesifik menolak komunikasi dari VLAN 30 ke VLAN 20, maka semua paket data yang berasal dari VLAN 30 dan ditujukan ke VLAN 20 akan diblokir oleh router. Artinya, perangkat di VLAN 30 tidak bisa mengakses perangkat di VLAN 20 melalui ping, file sharing, atau protokol lainnya.

Di bagian tengah gambar, terlihat bahwa dilakukan pengecekan alamat IP dari perangkat lain untuk memastikan apakah akses benar-benar terblokir. Biasanya, pengecekan ini dilakukan dengan perintah seperti ping atau traceroute untuk melihat apakah perangkat dapat mencapai tujuan yang seharusnya terblokir oleh ACL. Jika hasil pengecekan menunjukkan bahwa perangkat dari VLAN 30 tidak bisa berkomunikasi dengan VLAN 20, maka aturan ACL bekerja dengan baik. Sebaliknya, jika koneksi masih memungkinkan, maka ada kemungkinan kesalahan dalam konfigurasi ACL yang perlu diperbaiki.

Pada bagian bawah gambar, ACL telah dimatikan atau dihapus. Setelah ACL dinonaktifkan, lalu lintas antara VLAN yang sebelumnya diblokir kini bisa berjalan normal. Perangkat dari VLAN 30 yang sebelumnya tidak bisa mengakses VLAN 20 kini dapat melakukan komunikasi tanpa hambatan. Penghapusan ACL dilakukan dengan perintah seperti no access-list 100 atau dengan menghapus aturan spesifik yang menyebabkan pemblokiran. Setelah ACL dihapus, pengujian dilakukan kembali untuk memastikan bahwa perangkat kini dapat berkomunikasi dengan bebas tanpa batasan.

Proses ini menunjukkan bagaimana ACL mempengaruhi akses dalam jaringan, baik saat aturan diterapkan maupun saat dihapus. Dengan ACL, administrator dapat mengontrol komunikasi antar-VLAN untuk meningkatkan keamanan dan memastikan bahwa hanya lalu lintas yang diperbolehkan yang dapat terjadi. Sementara itu, saat ACL dinonaktifkan, jaringan kembali ke kondisi terbuka tanpa batasan akses. Pengaturan ini sangat penting dalam mengelola keamanan dan efisiensi lalu lintas data dalam sebuah sistem jaringan.

###  Troubleshooting dan Perbaikan Masalah. 
![Troubleshooting](cek-troubleshooting.jpg)

Troubleshooting dilakukan untuk menemukan dan memperbaiki masalah dalam konfigurasi jaringan, khususnya yang berkaitan dengan Access Control List (ACL). Ketika aturan ACL diterapkan, ada kemungkinan bahwa perangkat tertentu tidak dapat berkomunikasi sesuai yang diharapkan, sehingga perlu dilakukan pengecekan dan pemecahan masalah agar jaringan kembali berjalan normal.

Langkah pertama dalam troubleshooting adalah mengidentifikasi perangkat atau VLAN yang mengalami kendala. Misalnya, jika VLAN 30 tidak dapat mengakses internet seperti yang seharusnya, maka kita perlu memastikan bahwa aturan ACL yang mengizinkan akses ke jaringan eksternal sudah benar. Pengecekan awal bisa dilakukan dengan menggunakan perintah ping ke alamat IP tujuan, baik di dalam maupun di luar jaringan. Jika ping gagal, maka ada kemungkinan aturan ACL telah memblokir akses yang tidak seharusnya. Langkah berikutnya adalah mengecek konfigurasi ACL dengan melihat daftar aturan yang diterapkan pada router atau switch. Perintah seperti show access-lists digunakan untuk menampilkan aturan yang sedang berlaku, sehingga kita dapat melihat apakah ada kesalahan dalam penulisan aturan. Jika ditemukan aturan yang tidak sesuai, misalnya ada aturan deny yang seharusnya permit, maka konfigurasi ACL perlu diperbaiki.

Selain itu, kita juga bisa melakukan pengecekan pada interface yang menerapkan ACL. Perintah seperti show ip interface digunakan untuk melihat apakah ACL sudah diterapkan ke interface yang benar. Jika ACL diterapkan pada interface yang salah atau arah lalu lintasnya tidak sesuai, maka perangkat tidak akan bisa berkomunikasi sebagaimana mestinya. Dalam hal ini, aturan ACL perlu direvisi dan diterapkan ulang dengan perintah yang tepat. Setelah dilakukan perubahan atau perbaikan, langkah terakhir adalah menguji kembali akses jaringan dengan mencoba melakukan koneksi dari VLAN yang bermasalah. Jika perangkat kini bisa berkomunikasi seperti yang diharapkan, maka troubleshooting berhasil dilakukan. 


## **Kendala dan Solusi**  
1. Kesalahan Topologi pada Week 13

Kendala: Terdapat kesalahan pada jumlah PC yang ada di setiap departemen dalam topologi awal. Hal ini menyebabkan ketidaksesuaian dengan rencana jaringan.

Solusi: Topologi diperbaiki dengan menambahkan atau mengurangi jumlah PC sesuai kebutuhan masing-masing VLAN/departemen sebelum memulai konfigurasi lanjutan di Week 13.

2. Kesulitan Konfigurasi DHCP, DNS, dan NAT

Kendala: Tim mengalami hambatan dalam memahami dan mengimplementasikan konfigurasi DHCP, DNS, dan NAT, terutama dalam hal urutan dan hubungan antar konfigurasi.

Solusi: Diperlukan waktu tambahan untuk mempelajari ulang perintah dan alur konfigurasi. Proses dilakukan secara bertahap, dimulai dari DHCP, dilanjutkan DNS, dan terakhir NAT, hingga jaringan dapat berjalan stabil.

3. Konflik Alamat IP pada DHCP VLAN

Kendala: Saat mengkonfigurasi DHCP untuk VLAN 10 dan VLAN 40, muncul peringatan bahwa subnet yang digunakan overlaps dengan interface fisik tertentu (contoh: GigabitEthernet0/0.10 atau 0/1.40).

Solusi: Dilakukan pengecekan ulang terhadap konfigurasi interface dan subnet. Setelah disesuaikan dan konflik dihindari, konfigurasi berhasil disimpan dan DHCP berjalan normal.

4. Native VLAN Mismatch

Kendala: Terjadi pesan kesalahan CDP-4-NATIVE_VLAN_MISMATCH pada switch, menunjukkan bahwa native VLAN antara dua perangkat tidak cocok.

Solusi: Native VLAN disamakan antara port trunk antar switch dengan cara menyesuaikan konfigurasi VLAN dan mode trunk secara eksplisit (switchport trunk native vlan <id> jika diperlukan).

5. Akses Terbatas Akibat Kesalahan ACL

Kendala: Beberapa VLAN tidak dapat mengakses tujuan sesuai kebijakan, seperti VLAN 30 tidak bisa ke internet atau VLAN 50 tidak bisa ke DNS.

Solusi: Diperbaiki dengan menyusun ulang ACL agar lebih spesifik, menambahkan rule untuk port dan protokol tertentu (misalnya permit udp eq 53 untuk DNS dan permit tcp eq 80 untuk HTTP).



## **Kesimpulan**  
Seluruh konfigurasi jaringan berhasil diterapkan sesuai dengan kebutuhan proyek, termasuk implementasi VLAN, pengalokasian IP secara dinamis melalui DHCP, serta pengaturan akses jaringan menggunakan Access Control List (ACL). Setiap VLAN telah berhasil mendapatkan IP sesuai subnet-nya dan ACL berfungsi efektif untuk membatasi akses antar VLAN, sebagaimana dibuktikan dari hasil ping yang diblokir atau diterima sesuai dengan aturan yang diterapkan.

Beberapa proses troubleshooting dilakukan, seperti pengecekan ACL menggunakan perintah show access-lists dan debug ip packet, serta pengujian konektivitas melalui ping. Hal ini menunjukkan pentingnya pengujian berulang dan pemahaman mendalam terhadap urutan konfigurasi serta jenis protokol yang digunakan.
