
# [Proyek Perancangan & Implementasi Jaringan Enterprise PT. Nusantara Network] - [Pekan 12:   Implementasi Routing & WAN] 
## Anggota Kelompok dan Peran 
- **Muhammad Irgie Yanuar (10221022)** - Network Architect  
- **Noviansyah(10231072)** - Network Engineer  
- **Desnita Dwi Putri (10231030)** - Network Services Specialist  
- **Zaidan Ramadhan Arrazy (10221028)** - Security & Documentation Specialist   
## Daftar Isi 
1. [Pendahuluan](#pendahuluan)  
2. [Isi Laporan](#isi-laporan)    
1. [Kendala dan Solusi](#kendala-dan-solusi)  
2. [Kesimpulan](#kesimpulan)  
## **Pendahuluan**  

### **Latar Belakang**  
PT. Nusantara Network merupakan perusahaan di bidang teknologi informasi yang memiliki dua lokasi kantor (pusat dan cabang) dengan total 6 departemen dan server farm. Perusahaan membutuhkan infrastruktur jaringan yang aman, terkelola dengan baik, dan mampu mendukung pertumbuhan bisnis di masa depan. Proyek ini bertujuan untuk merancang solusi jaringan enterprise yang mengintegrasikan seluruh konsep jaringan komputer yang telah dipelajari.

### **Tujuan**  
1. Merancang topologi jaringan yang memenuhi kebutuhan bisnis PT. Nusantara Network  
2. Mengimplementasikan segmentasi jaringan menggunakan VLAN  
3. Menyediakan konektivitas antar-gedung melalui WAN dengan routing dinamis (OSPF)  
4. Menerapkan layanan jaringan (DHCP, DNS, NAT) dan keamanan (ACL)  
5. Membangun dokumentasi teknis yang komprehensif  

### **Ruang Lingkup**  
Proyek mencakup:  
- Perancangan topologi fisik dan logis  
- Pembagian subnet dan pengalamatan IP  
- Konfigurasi VLAN, trunking, dan routing antar-VLAN  
- Implementasi OSPF untuk koneksi WAN antar-gedung  
- Penyediaan layanan DHCP, DNS, dan NAT  
- Penerapan Access Control List (ACL)  
- Pengujian end-to-end dan troubleshooting  
 
## Isi Laporan

### Konfigurasi Routing Statis pada Jaringan Intra-gedung.

![Konfigurasi Statis](konfstatis.jpg)

Konfigurasi pada gambar tersebut menunjukkan proses pengaturan sebuah router Cisco untuk menghubungkan beberapa jaringan VLAN menggunakan metode yang disebut Router-on-a-Stick. Router-on-a-Stick adalah teknik yang memungkinkan satu port fisik pada router menangani lalu lintas dari beberapa VLAN melalui sub-interface. Ini sangat berguna untuk menghubungkan beberapa jaringan yang terpisah secara logis (VLAN) tetapi masih menggunakan infrastruktur fisik yang sama, seperti dalam kasus penghubungan antar departemen dalam satu gedung, atau bahkan antar gedung yang terpisah secara fisik namun tetap dalam satu sistem jaringan. Dalam konfigurasi tersebut, administrator pertama-tama masuk ke mode konfigurasi global (conf t), lalu membuat sub-interface pada interface fisik FastEthernet0/0, yaitu FastEthernet0/0.40 dan FastEthernet0/0.50. Masing-masing sub-interface diberi konfigurasi encapsulation dot1Q, yang merupakan standar untuk menandai lalu lintas VLAN pada jaringan Ethernet, dengan nomor VLAN 40 dan 50. Setelah itu, tiap sub-interface diberikan alamat IP (192.168.40.1 dan 192.168.50.1) sebagai gateway untuk masing-masing VLAN. IP ini berfungsi sebagai alamat yang akan digunakan oleh perangkat klien dalam VLAN tersebut untuk mengirim data keluar dari jaringan lokal mereka.

Setelah konfigurasi sub-interface selesai, router menyimpan konfigurasi ke dalam memori agar tetap aktif meskipun router dimatikan atau direstart. Kemudian, administrator menjalankan perintah show ip route untuk melihat routing table, yaitu daftar jaringan yang dikenali dan bisa dijangkau oleh router. Output-nya menunjukkan bahwa router telah mengenali beberapa jaringan yang “directly connected” (langsung terhubung) melalui sub-interface FastEthernet0/0.40 dan 0.50, yaitu jaringan 192.168.40.0/24 dan 192.168.50.0/24. Ini menandakan bahwa router telah berhasil menghubungkan VLAN 40 dan VLAN 50. Dengan konfigurasi ini, router memungkinkan komunikasi antar perangkat yang berada di VLAN berbeda, sehingga pengguna di gedung atau ruangan berbeda, misalnya gedung sebelah yang dapat saling bertukar data meskipun mereka berada dalam VLAN yang berbeda. Semua data dari berbagai VLAN akan melewati satu kabel trunk menuju router, dan router akan meneruskannya sesuai dengan VLAN ID dan alamat IP tujuan.


![Konfigurasi Statis2](konfstatis2.jpg)

Konfigurasi ini pada sebuah switch untuk mengatur VLAN 50 yang dinamai “OPERASIONAL”. VLAN (Virtual Local Area Network) digunakan untuk membagi jaringan fisik menjadi beberapa jaringan logis. Dalam kasus ini, VLAN 50 digunakan khusus untuk gedung Operasional, sehingga semua perangkat di gedung tersebut tergabung dalam jaringan VLAN 50 agar bisa berkomunikasi hanya dengan perangkat lain di VLAN yang sama, meskipun terkoneksi ke switch yang sama.

Pada awalnya, muncul error saat mencoba membuat VLAN karena perintah vlan 50 diberikan di mode yang salah (harusnya di mode konfigurasi global). Setelah masuk ke mode konfigurasi dengan conf t, VLAN 50 berhasil dibuat dan diberi nama “OPERASIONAL” menggunakan perintah name OPERASIONAL. Lalu, interface FastEthernet0/1 dikonfigurasi sebagai trunk. Trunk port ini penting karena berfungsi untuk mengirimkan trafik dari berbagai VLAN melalui satu kabel ke perangkat lain seperti router atau switch lain. Ini artinya FastEthernet0/1 menghubungkan switch ini ke router (atau ke switch lain) agar VLAN 50 bisa berkomunikasi ke luar gedung jika diperlukan.

Kemudian, interface FastEthernet0/2 sampai 0/24 dikonfigurasi sebagai access port, yang berarti port tersebut hanya akan membawa satu VLAN, dalam hal ini VLAN 50. Perintah switchport access vlan 50 memastikan bahwa semua perangkat yang terhubung ke port-port itu akan otomatis masuk ke jaringan VLAN 50, yaitu jaringan khusus untuk gedung operasional.

Secara sederhana, konfigurasi ini bertujuan agar seluruh perangkat di gedung Operasional bisa saling berkomunikasi dalam satu jaringan terisolasi (VLAN 50), dan melalui port trunk, jaringan tersebut juga bisa terhubung ke jaringan pusat atau router untuk akses ke jaringan lain jika diperlukan. Output yang muncul seperti "LINEPROTO-5-UPDOWN" menunjukkan bahwa port yang diaktifkan sedang mengalami perubahan status koneksi (naik atau turun), yang umum terjadi saat konfigurasi baru diterapkan.

![Konfigurasi Statis3](konfstatis3.jpg)

VLAN 50 dibuat dan diberi nama “OPERASIONAL”. Kemudian, port FastEthernet0/1 dikonfigurasi sebagai trunk dengan perintah switchport mode trunk, yang artinya port ini akan membawa trafik dari beberapa VLAN, termasuk VLAN 50. Trunking diperlukan agar VLAN 50 dari switch ini bisa berkomunikasi dengan VLAN 50 dari switch atau router lain. Namun, perlu diperhatikan bahwa tidak ada perintah eksplisit untuk mengatur native VLAN, sehingga kemungkinan besar switch masih menggunakan default native VLAN 1, yang menyebabkan ketidaksesuaian dengan sisi lain yang menggunakan VLAN 40 sebagai native.

Selanjutnya, port FastEthernet0/2 hingga FastEthernet0/12 dikonfigurasi sebagai access port, artinya masing-masing port hanya akan digunakan oleh satu perangkat dan akan masuk ke dalam VLAN 50 secara otomatis. Ini dilakukan dengan perintah switchport mode access dan switchport access vlan 50, yang memastikan semua perangkat yang dicolokkan ke port-port tersebut langsung tergabung dalam jaringan gedung Operasional (VLAN 50). Secara keseluruhan, konfigurasi ini bertujuan untuk membentuk dan mengelola VLAN 50 khusus untuk gedung Operasional agar perangkat di dalamnya dapat berkomunikasi dalam satu jaringan.

### Implementasi Routing Dinamis (OSPF) untuk Koneksi Antar-gedung. 
 
 ![Konfigurasi dinamis](konfdinamis.jpg)

Konfigurasi ini dilakukan untuk mengelompokkan port-port tertentu di switch ke dalam satu jaringan VLAN, sehingga perangkat seperti komputer atau printer yang terhubung ke port-port tersebut bisa saling berkomunikasi seolah-olah berada di jaringan yang sama, walaupun mungkin tersebar secara fisik di tempat yang berbeda. Dalam hal ini, VLAN 40 digunakan dan dinamai "MARKETING", yang menunjukkan bahwa VLAN ini ditujukan untuk departemen Marketing.

Langkah pertama adalah masuk ke mode konfigurasi menggunakan perintah enable dan conf t. Setelah itu, dibuat VLAN 40 dan diberi nama "MARKETING" agar mudah dikenali. Port FastEthernet0/1 dikonfigurasi sebagai trunk, yaitu jalur utama yang bisa membawa data dari banyak VLAN sekaligus, termasuk VLAN 40. Port trunk ini biasanya digunakan untuk menghubungkan antar switch, agar VLAN yang sama bisa digunakan di beberapa switch yang berbeda.

Kemudian, port FastEthernet0/2 sampai 0/24 disetel sebagai access port, yang artinya masing-masing port hanya mendukung satu VLAN saja, yaitu VLAN 40. Jadi, setiap perangkat yang dicolokkan ke port-port ini otomatis akan menjadi bagian dari VLAN MARKETING. Ini membuat jaringan jadi lebih rapi, aman, dan efisien, karena perangkat dari departemen lain tidak bisa mengakses VLAN ini secara langsung.

Dengan cara ini, seluruh perangkat yang tergabung di VLAN 40 (MARKETING) bisa saling terkoneksi dalam satu jaringan logis yang sama, meskipun secara fisik mereka bisa tersebar di tempat atau ruangan berbeda. Ini merupakan praktik umum dalam pengelolaan jaringan di kantor atau organisasi besar.

### Simulasi Koneksi WAN Antar Gedung.

![Simuasi WAN](simulasi.jpg)

Gambar ini menunjukkan hasil pengiriman paket ICMP (Internet Control Message Protocol), yang dalam konteks ini digunakan untuk melakukan tes koneksi (ping) antar perangkat dalam jaringan. Setiap baris di tabel menunjukkan satu simulasi pengiriman paket dari satu perangkat (source) ke perangkat lain (destination), dengan status “Successful” yang berarti paket berhasil dikirim dan diterima tanpa hambatan. Misalnya, pada baris pertama, paket ICMP berhasil dikirim dari KC1 ke KC2, sedangkan pada baris lainnya juga terlihat keberhasilan pengiriman antara berbagai pasangan perangkat lain seperti KC30 ke KC29, SDM 1 ke SDM 20, dan seterusnya. Kolom “Type” menunjukkan bahwa semua paket bertipe ICMP, dan “Time(sec)” yang bernilai 0.000 menandakan bahwa simulasi ini dilakukan sangat cepat, hampir tanpa delay, yang umum terjadi di simulasi digital.

Keberhasilan semua paket ICMP ini merupakan indikator penting bahwa jaringan telah dikonfigurasi dengan benar, termasuk alamat IP, subnet, pengaturan VLAN, trunking antar switch, dan pengaturan routing (baik routing antar VLAN maupun routing antar jaringan berbeda). Artinya, perangkat-perangkat yang berada dalam satu gedung maupun antar gedung sudah dapat saling terhubung secara logis. Ini juga menunjukkan bahwa konfigurasi baik di switch (seperti VLAN dan port access/trunk), router (subinterface, routing), maupun pengalamatan IP sudah sinkron dan tidak terdapat konflik.

#### Tabel routing pada router utama dengan penjelasan detail

![Table Routering](tabel.jpg)

show ip route adalah perintah yang digunakan untuk menampilkan tabel routing, yaitu daftar semua jaringan yang dikenal oleh router beserta informasi tentang bagaimana dan melalui interface mana router dapat menjangkau jaringan-jaringan tersebut. Dalam konteks gambar ini, router menunjukkan bahwa ia mengenal enam jaringan lokal dengan subnet berbeda, yang semuanya secara langsung terhubung melalui antarmuka FastEthernet dengan subinterface yang berbeda. Setiap baris dimulai dengan huruf C, yang berarti “Connected”, menandakan bahwa jaringan tersebut terhubung langsung dengan router, tanpa harus melalui router lain atau menggunakan protokol routing seperti OSPF, EIGRP, atau RIP. Misalnya, jaringan 192.168.1.0/24 terhubung melalui antarmuka fisik FastEthernet0/0, sementara jaringan 192.168.10.0/24 hingga 192.168.50.0/24 terhubung melalui subinterface FastEthernet0/0.10 hingga FastEthernet0/0.50. Subinterface ini biasanya digunakan dalam skenario router-on-a-stick, di mana satu port fisik router dibagi menjadi beberapa subinterface logis, masing-masing dikonfigurasi dengan IP dari VLAN berbeda. Ini menandakan bahwa router tersebut sedang digunakan untuk menghubungkan beberapa VLAN (seperti VLAN 10, 20, 30, 40, dan 50), yang biasanya berasal dari switch yang sudah dikonfigurasi menggunakan 802.1Q trunking.

#### Analisis performa routing dinamis vs statis
| **Aspek**              | **Routing Statis**                                                                                 | **Routing Dinamis (OSPF)**                                                                                  |
|-------------------------|---------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------|
| **Cara kerja**         | Admin harus masukkan rute satu per satu secara manual.                                              | Router berbagi info rute otomatis dengan router lain.                                                       |
| **Cocok untuk**        | Jaringan kecil, jarang berubah.                                                                    | Jaringan besar, sering berubah, atau banyak gedung.                                                         |
| **Kalau ada perubahan**| Tidak otomatis, harus diubah manual.                                                               | Otomatis, router menyesuaikan sendiri.                                                                     |
| **Beban kerja router** | Ringan, tidak ada beban tambahan dari protokol.                                                    | Ada sedikit beban tambahan karena pertukaran info antar-router.                                             |
| **Kemudahan**          | Mudah kalau jaringannya kecil.                                                                    | Lebih mudah untuk jaringan besar karena tidak perlu atur rute satu-satu.                                    |
| **Kekuatan**          | Sederhana, hemat sumber daya.                                                                     | Lebih pintar, bisa atur jalur terbaik dan ada backup kalau jalur utama gagal.                              |
| **Kelemahan**         | Repot kalau jaringan besar, rawan salah input.                                                     | Perlu router yang lebih kuat, pengaturan awal lebih rumit.                                                  |
| **Contoh penggunaan** | Hubungkan VLAN di satu gedung pakai Router-on-a-Stick.                                             | Hubungkan jaringan antar gedung pakai OSPF.                                                                |


## **Kendala dan Solusi**  
| **Kendala**                                                                                       | **Solusi**                                                                                                   |
|--------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------|
| Atur rute manual makin ribet kalau jaringan makin besar.                                          | Pakai routing dinamis (OSPF) supaya router saling tukar info otomatis.                                      |
| VLAN atau trunking salah atur, jadi antar-VLAN tidak bisa komunikasi.                            | Cek ulang konfigurasi VLAN dan trunk, pastikan native VLAN sama di kedua sisi.                             |
| Ada kesalahan IP atau subnet, bikin perangkat tidak bisa konek.                                   | Rencanakan pembagian IP dengan baik, gunakan DHCP untuk atur IP otomatis.                                   |
| Beban router bertambah karena protokol dinamis (OSPF) di jaringan besar.                          | Optimalkan OSPF, atur area OSPF dengan baik, atau kalau perlu upgrade perangkat router.                     |

---


## **Kesimpulan**  
 Routing statis bagus kalau jaringannya kecil dan jarang berubah karena pengaturannya simpel. Tapi kalau jaringan makin besar atau sering berubah, pakai routing statis akan makin sulit dan rawan kesalahan
 
 Routing dinamis seperti OSPF jauh lebih cocok untuk jaringan besar seperti di PT. Nusantara Network karena router bisa otomatis mencari jalur terbaik, menyesuaikan kalau ada masalah, dan lebih mudah dikelola. Walaupun awalnya perlu pengaturan yang lebih rumit, routing dinamis lebih kuat dan siap mendukung pertumbuhan perusahaan di masa depan.
